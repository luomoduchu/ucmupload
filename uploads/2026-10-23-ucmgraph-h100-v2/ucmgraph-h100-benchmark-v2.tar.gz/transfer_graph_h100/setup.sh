#!/usr/bin/env bash
# Run inside the official vLLM 0.27.1 CUDA container, as root.
set -euo pipefail
UCM_REPO=${UCM_REPO:-https://github.com/luomoduchu/unified-cache-management.git}
UCM_REV=${UCM_REV:-89909fd0c5c6fb140a5dd9e0ec0ded213e4fa6e5}
UCM_DIR=${UCM_DIR:-/workspace/ucm-source}
python - <<'PY'
from importlib.metadata import version
assert version('vllm').split('+')[0] == '0.27.1', version('vllm')
PY
test -x /usr/local/cuda/bin/nvcc || {
  echo 'UCM CUDA build requires /usr/local/cuda/bin/nvcc and matching CUDA headers.' >&2
  exit 1
}
apt-get update
apt-get install -y git build-essential libaio-dev libnuma-dev curl
python -m pip install 'setuptools>=64' 'cmake>=3.18,<4' wheel ninja pybind11 PyYAML 'wrapt==1.17.2'
# Refuse to reuse an existing checkout, preserving any local work.
git clone --branch graph "$UCM_REPO" "$UCM_DIR"
git -C "$UCM_DIR" checkout --detach "$UCM_REV"
cd "$UCM_DIR"
PLATFORM=cuda ENABLE_SPARSE=false ENABLE_GDR=0 \
  python -m pip install -v -e . --no-build-isolation --no-deps
python -m pip check
ENABLE_UCM_PATCH=1 python - <<'PY'
from ucm.store.pipeline.connector import UcmPipelineStore
from ucm.integration.vllm.ucm_connector import UCMConnector
print('UCM native pipeline and vLLM connector imports OK')
PY
git rev-parse HEAD
python -m pip freeze > /workspace/ucm-pip-freeze.txt
