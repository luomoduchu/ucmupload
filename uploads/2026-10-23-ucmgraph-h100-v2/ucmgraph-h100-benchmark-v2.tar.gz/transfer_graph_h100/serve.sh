#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
MODE=${1:?Usage: bash serve.sh off|on}
[[ "$MODE" == off || "$MODE" == on ]] || exit 2
export MODEL=${MODEL:-/models/Qwen3-32B}
export STORAGE_ROOT=${STORAGE_ROOT:-/cache/ucm-graph-bench}
export RUN_DIR=${RUN_DIR:-/workspace/results/$MODE}
export MODE
mkdir -p "$STORAGE_ROOT" "$RUN_DIR"
export RUN_DIR=$(realpath "$RUN_DIR")
export STORAGE_ROOT=$(realpath "$STORAGE_ROOT")
export ENABLE_UCM_PATCH=1
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0,1}
export UCM_LOG_PATH="$RUN_DIR/ucm-logs"
mkdir -p "$UCM_LOG_PATH"
python - "$HERE/ucm.yaml" <<'PY'
import os, sys, yaml
from importlib.metadata import version
assert version('vllm').split('+')[0] == '0.27.1'
with open(sys.argv[1]) as f:
    config = yaml.safe_load(f)
c = config['ucm_connectors'][0]['ucm_connector_config']
c['cache_transfer_graph'] = os.environ['MODE'] == 'on'
c['storage_backends'] = os.environ['STORAGE_ROOT']
with open(os.path.join(os.environ['RUN_DIR'], 'ucm.yaml'), 'w') as f:
    yaml.safe_dump(config, f, sort_keys=False)
PY
KV_CONFIG=$(python - <<'PY'
import json, os
print(json.dumps(dict(kv_connector='UCMConnector',
    kv_connector_module_path='ucm.integration.vllm.ucm_connector', kv_role='kv_both',
    kv_connector_extra_config={'UCM_CONFIG_FILE':os.environ['RUN_DIR']+'/ucm.yaml'})))
PY
)
nvidia-smi > "$RUN_DIR/nvidia-smi.txt"
nvidia-smi topo -m > "$RUN_DIR/topology.txt"
df -h "$STORAGE_ROOT" > "$RUN_DIR/storage.txt"
cmd=(vllm serve "$MODEL" --served-model-name qwen3-32b
  --host 127.0.0.1 --port "${PORT:-8000}"
  --tensor-parallel-size 2 --dtype bfloat16
  --max-model-len 16384 --max-num-seqs 8 --max-num-batched-tokens 8192
  --gpu-memory-utilization 0.90 --block-size 128
  --no-enable-prefix-caching --seed 42 --kv-transfer-config "$KV_CONFIG")
printf '%q ' "${cmd[@]}" > "$RUN_DIR/command.txt"
printf '\n' >> "$RUN_DIR/command.txt"
"${cmd[@]}" 2>&1 | tee "$RUN_DIR/server.log"
