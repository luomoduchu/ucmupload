#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
MODE=${1:?Usage: bash bench.sh off|on}
[[ "$MODE" == off || "$MODE" == on ]] || exit 2
MODEL=${MODEL:-/models/Qwen3-32B}
RUN_DIR=${RUN_DIR:-/workspace/results/$MODE}
BASE_URL=http://127.0.0.1:${PORT:-8000}
# A fresh result directory prevents mixing measurements from different launches.
OUT=$(mktemp -d "$RUN_DIR/bench-XXXXXXXX")
curl --fail --silent --show-error "$BASE_URL/health" > /dev/null
args=(vllm bench serve --backend vllm --base-url "$BASE_URL"
  --endpoint /v1/completions --model qwen3-32b --tokenizer "$MODEL"
  --dataset-name random --seed 42 --num-prompts "${NUM_PROMPTS:-16}"
  --random-input-len "${INPUT_LEN:-8192}" --random-output-len "${OUTPUT_LEN:-128}"
  --random-range-ratio 0 --random-prefix-len 0 --ignore-eos
  --max-concurrency "${CONCURRENCY:-4}" --request-rate inf
  --percentile-metrics ttft,tpot,itl,e2el --metric-percentiles 50,95,99
  --save-result --save-detailed --result-dir "$OUT")
printf '%q ' "${args[@]}" > "$OUT/command.txt"
# Fixed seed, tokenizer and request parameters reproduce the same prompt set.
# Seed writes and a replay warm-up are excluded from the timed comparison.
for phase in seed warmup; do
  "${args[@]}" --result-filename "$phase.json" 2>&1 | tee "$OUT/$phase.log"
  python - "$OUT/$phase.json" <<'PY'
import json, sys
with open(sys.argv[1]) as f:
    result = json.load(f)
assert result['completed'] == result['num_prompts'], 'Seed/warmup requests failed'
PY
  sleep "${SETTLE_SECONDS:-10}"
done
for round in 1 2 3; do
  curl -fsS "$BASE_URL/metrics" > "$OUT/$round.before.prom"
  "${args[@]}" --result-filename "$round.json" 2>&1 | tee "$OUT/$round.log"
  # Allow the worker metrics export interval to elapse.
  sleep "${SETTLE_SECONDS:-10}"
  curl -fsS "$BASE_URL/metrics" > "$OUT/$round.after.prom"
  python "$HERE/check_metrics.py" "$MODE" "$OUT/$round.before.prom" \
    "$OUT/$round.after.prom" "$OUT/$round.json" | tee "$OUT/$round.check.txt"
done
echo "Results: $OUT"
