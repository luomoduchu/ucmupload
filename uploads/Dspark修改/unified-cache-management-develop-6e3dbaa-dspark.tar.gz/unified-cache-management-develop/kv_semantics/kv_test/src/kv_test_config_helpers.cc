#include "kv_test_config_helpers.h"
#include <algorithm>
#include <string>
#include <utility>

namespace kv::bench {
namespace {

constexpr int kFakeBackendAclDeviceId = 0;

bool HasProvider(const KvTestConfig& config, kv::TransProviderType providerType)
{
    return std::any_of(config.asuClientConfig.transportConfigs.begin(),
                       config.asuClientConfig.transportConfigs.end(),
                       [providerType](const kv::TransportConfig& transportConfig) {
                           return transportConfig.providerType == providerType;
                       });
}

void PatchFakeBackendTransportConfig(kv::TransportConfig& config,
                                     const KvTestFakeBackendConfig& fakeConfig)
{
    const auto fakeBackendDeviceId =
        config.deviceId < 0 ? kFakeBackendAclDeviceId : config.deviceId;
    config.deviceId = fakeBackendDeviceId;
    config.providerType = kv::TransProviderType::FAKE;
    config.attrs.try_emplace("kernel_count", "1");
    config.attrs.try_emplace("quiet_count", "1");
    config.attrs["kv_ns_id"] = std::to_string(config.nodeId);
    config.attrs.try_emplace("dtype", "0");
    config.attrs.try_emplace("dspec", "0");
    config.attrs.try_emplace("lr", "false");
    config.attrs["fake_backend.path"] = fakeConfig.storePath;
    config.attrs["fake_backend.latency_us"] = std::to_string(fakeConfig.latencyUs);
    config.attrs["fake_backend.worker_threads"] = std::to_string(fakeConfig.workerThreads);
    config.attrs["fake_backend.complete_immediately"] =
        fakeConfig.completeImmediately ? "true" : "false";
    config.attrs["fake_backend.device_id"] = std::to_string(fakeBackendDeviceId);
    if (config.endpoints.empty()) {
        kv::NodeEndpoint endpoint;
        endpoint.ip = "fake_backend";
        endpoint.port = 19001;
        endpoint.protocol = kv::Protocol::TCP;
        config.endpoints.emplace_back(std::move(endpoint));
    }
}

}  // namespace

bool HasFakeProvider(const KvTestConfig& config)
{
    return HasProvider(config, kv::TransProviderType::FAKE);
}

bool IsAivProviderMode(const KvTestConfig& config)
{
    return HasProvider(config, kv::TransProviderType::AIV);
}

bool IsAicpuProviderMode(const KvTestConfig& config)
{
    return HasProvider(config, kv::TransProviderType::AICPU);
}

DeviceAllocationPolicy AllocationPolicyForConfig(const KvTestConfig& config)
{
    return IsAivProviderMode(config) ? DeviceAllocationPolicy::AIV_REGISTERABLE
                                     : DeviceAllocationPolicy::DEFAULT;
}

void MaybePrepareFakeBackend(KvTestConfig& config)
{
    if (!HasFakeProvider(config)) { return; }

    if (config.fakeBackend.storePath.empty()) {
        config.fakeBackend.storePath = "./kv-test-fake-backend-store";
    }

    config.asuClientConfig.attrs.try_emplace("hash_table.type", "RING_HASH");
    config.asuClientConfig.attrs.try_emplace("ring_hash.virtual_node_count", "128");
    for (auto& transportConfig : config.asuClientConfig.transportConfigs) {
        if (transportConfig.providerType == kv::TransProviderType::FAKE) {
            PatchFakeBackendTransportConfig(transportConfig, config.fakeBackend);
        }
    }
}

}  // namespace kv::bench
