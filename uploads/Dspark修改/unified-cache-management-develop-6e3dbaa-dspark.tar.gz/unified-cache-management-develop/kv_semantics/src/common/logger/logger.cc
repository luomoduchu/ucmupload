/**
 * MIT License
 *
 * Copyright (c) 2026 Huawei Technologies Co., Ltd. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * */

#include "logger.h"

namespace kv::logger {

void Log(Level lv, std::string file, std::string func, int line, std::string msg)
{
    SourceLocation loc{InternSourceString(std::move(file)), InternSourceString(std::move(func)),
                       line};
    Logger::GetInstance().Log(std::move(lv), std::move(loc), std::move(msg));
}

void LogFileOnly(Level lv, std::string file, std::string func, int line, std::string msg)
{
    SourceLocation loc{InternSourceString(std::move(file)), InternSourceString(std::move(func)),
                       line};
    Logger::GetInstance().LogFileOnly(std::move(lv), std::move(loc), std::move(msg));
}

void LogRateLimit(Level lv, std::string file, std::string func, int line, std::string msg)
{
    SourceLocation loc{InternSourceString(std::move(file)), InternSourceString(std::move(func)),
                       line};
    if (Logger::GetInstance().FilterCallSite(loc.file, line)) {
        Logger::GetInstance().Log(std::move(lv), std::move(loc), std::move(msg));
    }
}

void Setup(const std::string& path, int max_files, int max_size)
{
    Logger::GetInstance().Setup(path, max_files, max_size);
}

void Flush() { Logger::GetInstance().Flush(); }

bool isEnabledFor(Level lv) { return Logger::GetInstance().IsEnabledFor(lv); }

}  // namespace kv::logger
