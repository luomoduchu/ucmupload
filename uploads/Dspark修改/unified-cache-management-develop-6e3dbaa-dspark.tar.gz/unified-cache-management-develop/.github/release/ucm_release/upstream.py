"""Registry-owned runtime selection and raw Builder capability resolution.

Published OCI objects are the formal source of truth: runtime tags decide which
versions exist, member configs (or targeted native fallback) decide the Wheel
capability, and raw Builder member digests decide Builder identity. Upstream
Git is not read.
"""

from __future__ import annotations

import copy
import hashlib
import re
from collections.abc import Callable, Mapping, Sequence
from typing import Any

from packaging.version import InvalidVersion, Version

from . import builders, registry
from . import runtime as runtime_contract
from . import serialization, version_config

SELECTION_KIND = "ucm-runtime-selection"
SELECTION_SCHEMA_VERSION = 3
CANDIDATES_KIND = "ucm-runtime-candidates"
CANDIDATES_SCHEMA_VERSION = 1
SUPPORTED_ARCHITECTURES = ("amd64", "arm64")
RUNTIME_CHANNEL_PRIORITY = ("stable", "rc", "nightly")

_DIGEST = re.compile(r"sha256:[0-9a-f]{64}")
_FORMAL_TAG = re.compile(
    r"^v(?P<version>[0-9]+\.[0-9]+\.[0-9]+(?:rc[0-9]+)?)"
    r"(?P<suffix>(?:-[A-Za-z0-9_.]+)*)$"
)
_NIGHTLY_TAG = re.compile(
    r"^nightly-releases-v(?P<version>[0-9]+\.[0-9]+\.[0-9]+rc(?:[0-9]+)?)"
    r"(?P<suffix>(?:-[A-Za-z0-9_.]+)*)$"
)
_SGLANG_CANN_SUFFIX = re.compile(r"^cann[0-9]+\.[0-9]+\.[0-9]+-(?:910b|a3)$")

_WHEEL_BUILD_FIELDS = {
    "id",
    "product_id",
    "build_group",
    "backend",
    "accelerator",
    "accelerator_runtime",
    "variant",
    "soc_version",
    "runtime_variant",
    "python_version",
    "python_abi",
    "manylinux",
    "cpu_arch",
    "source_image",
    "source_image_digest",
    "build_mode",
    "recipe_revision",
    "sync_mode",
}
_RUNTIME_FIELDS = {
    "id",
    "product_id",
    "runtime_repository",
    "runtime_tag",
    "runtime_digest",
    "runtime_variant",
    "backend",
    "accelerator_runtime",
    "variant",
    "soc_version",
    "python_version",
    "python_abi",
    "os_id",
    "os_version",
    "glibc_version",
    "architectures",
    "member_references",
    "wheel_build_ids",
    "version",
    "channel",
    "target_repository",
    "target_tag",
}
_PROBLEM_FIELDS = {"backend", "capability", "reason", "runtime"}


def _mapping(value: object, context: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{context}: expected a mapping")
    return dict(value)


def _string(mapping: Mapping[str, object], key: str, context: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{context}: {key} must be a non-empty string")
    return value.strip()


def _parsed_sglang_tag(tag: str) -> dict[str, object] | None:
    """Parse versioned SGLang CUDA and CANN image tags (stable or RC)."""

    match = _FORMAL_TAG.fullmatch(tag)
    if match is None:
        return None
    suffix = match.group("suffix")
    tokens = [token for token in suffix.removeprefix("-").split("-") if token]
    is_cuda = all(re.fullmatch(r"cu[0-9]+|runtime", token) for token in tokens)
    is_cann = (
        len(tokens) == 2 and _SGLANG_CANN_SUFFIX.fullmatch("-".join(tokens)) is not None
    )
    if not is_cuda and not is_cann:
        return None
    if is_cuda and (
        sum(token.startswith("cu") for token in tokens) != 1
        or tokens.count("runtime") > 1
    ):
        return None
    try:
        version = Version(match.group("version"))
    except InvalidVersion:
        return None
    channel = "rc" if version.is_prerelease else "stable"
    variant = "a2" if "910b" in tokens else "a3" if "a3" in tokens else "default"
    return {
        "tag": tag,
        "version": version,
        "version_text": match.group("version"),
        "channel": channel,
        "suffix": suffix,
        "tokens": tokens,
        "variant": variant,
        "backend": f"cann-{variant}" if is_cann else "cuda",
    }


def _parsed_runtime_tag(product_id: str, tag: str) -> dict[str, object] | None:
    if product_id == "sglang":
        return _parsed_sglang_tag(tag)
    nightly = _NIGHTLY_TAG.fullmatch(tag) if product_id == "vllm-ascend" else None
    formal = _FORMAL_TAG.fullmatch(tag)
    match = nightly or formal
    if match is None:
        return None
    suffix = match.group("suffix")
    tokens = [token for token in suffix.removeprefix("-").split("-") if token]
    if product_id == "vllm":
        if any(token in {"x86_64", "aarch64"} for token in tokens):
            return None
        if any(
            re.fullmatch(r"cu[0-9]+|ubuntu[0-9]+", token) is None for token in tokens
        ):
            return None
        if (
            sum(token.startswith("cu") for token in tokens) > 1
            or sum(token.startswith("ubuntu") for token in tokens) > 1
        ):
            return None
        variant = "default"
        backend = "cuda"
    elif product_id == "vllm-ascend":
        if any(token not in {"310p", "a3", "a5", "openeuler"} for token in tokens):
            return None
        accelerator_tokens = set(tokens) & {"310p", "a3", "a5"}
        if len(accelerator_tokens) > 1 or tokens.count("openeuler") > 1:
            return None
        variant = next(iter(accelerator_tokens), "a2")
        backend = f"cann-{variant}"
    else:
        raise ValueError(f"unsupported runtime product {product_id!r}")
    try:
        version = Version(match.group("version"))
    except InvalidVersion:
        return None
    channel = (
        "nightly"
        if nightly is not None
        else "rc" if version.is_prerelease else "stable"
    )
    return {
        "tag": tag,
        "version": version,
        "version_text": match.group("version"),
        "channel": channel,
        "suffix": suffix,
        "tokens": tokens,
        "variant": variant,
        "backend": backend,
    }


def _is_sglang_runtime_variant(product_id: str, parsed: Mapping[str, object]) -> bool:
    """SGLang publishes CUDA ``-runtime`` tags, which are not UCM build inputs."""

    return product_id == "sglang" and "runtime" in set(parsed.get("tokens", ()))


def _without_sglang_runtime_tags(
    product_id: str, selected: Sequence[Mapping[str, str]]
) -> list[dict[str, str]]:
    """Drop SGLang's image-only CUDA runtime tags from build candidates."""

    if product_id != "sglang":
        return [dict(item) for item in selected]
    return [
        dict(item)
        for item in selected
        if item.get("channel") == "pinned"
        or not str(item.get("runtime_tag", "")).endswith("-runtime")
    ]


def _version_is_in_selector(version: Version, selector: Version) -> bool:
    return version.release[: len(selector.release)] == selector.release


def _preferred_runtime_tags(
    candidates: Sequence[Mapping[str, object]],
) -> list[Mapping[str, object]]:
    """Choose one channel and complete version from a candidate cohort."""

    channel = next(
        (
            value
            for value in RUNTIME_CHANNEL_PRIORITY
            if any(item.get("channel") == value for item in candidates)
        ),
        None,
    )
    if channel is None:
        return []
    channel_candidates = [item for item in candidates if item.get("channel") == channel]
    winning_version = max(Version(str(item["version"])) for item in channel_candidates)
    return [
        item
        for item in channel_candidates
        if Version(str(item["version"])) == winning_version
    ]


def _validated_raw_selector(
    product_id: str,
    index: int,
    raw_selector: object,
) -> tuple[Mapping[str, object], str]:
    """Validate a selector and return its numeric range or opaque Tag."""

    context = f"{product_id} runtime selector[{index}]"
    if not isinstance(raw_selector, Mapping) or set(raw_selector) != {
        "raw",
        "version",
        "tag",
    }:
        raise ValueError(f"{context}: malformed selector")
    explicit_tag = raw_selector.get("tag")
    if explicit_tag is None:
        version = version_config.runtime_selector_version(
            raw_selector.get("version"), f"{context} version"
        )
        expected_raw = version
    else:
        if raw_selector.get("version") is not None:
            raise ValueError(
                f"{context}: explicit Runtime tag must use @tag without a version range"
            )
        if (
            not isinstance(explicit_tag, str)
            or version_config.OCI_TAG_PATTERN.fullmatch(explicit_tag) is None
        ):
            raise ValueError(f"{context}: explicit Runtime tag is not a valid OCI tag")
        version = explicit_tag
        expected_raw = f"@{explicit_tag}"
    if raw_selector.get("raw") != expected_raw:
        raise ValueError(f"{context}: raw selector is inconsistent")
    return raw_selector, version


def _select_runtime_tags(
    product: Mapping[str, object],
    tags: Sequence[str],
    *,
    excluded_variants: Sequence[str] = (),
    latest_only: bool = False,
) -> list[dict[str, str]]:
    """Resolve version.ini ranges and exact Tag pins to published Runtimes.

    ``latest_only`` keeps the newest numeric range and every explicit Tag.
    Pins have no version ordering and never participate in automatic selection.
    """

    product_id = _string(product, "id", "release product")
    raw_selectors = product.get("runtime_selectors")
    if not isinstance(raw_selectors, list) or not raw_selectors:
        raise ValueError(f"{product_id}: version.ini has no Runtime selectors")
    selectors = [
        (index, *_validated_raw_selector(product_id, index, raw_selector))
        for index, raw_selector in enumerate(raw_selectors)
    ]
    range_versions = {
        index: Version(text)
        for index, selector, text in selectors
        if selector["tag"] is None
    }
    if latest_only and range_versions:
        newest_version = max(range_versions.values())
        newest_indexes = [
            index
            for index, version in range_versions.items()
            if version == newest_version
        ]
        if len(newest_indexes) > 1:
            raise ValueError(
                f"{product_id}: runtime selectors {newest_indexes} share the "
                f"newest version {newest_version}; the latest selector is ambiguous"
            )
        selectors = [
            item
            for item in selectors
            if item[1]["tag"] is not None or item[0] == newest_indexes[0]
        ]
    available_tags = sorted(set(str(tag) for tag in tags))
    parsed_by_tag = {
        tag: parsed
        for tag in available_tags
        if (parsed := _parsed_runtime_tag(product_id, tag)) is not None
    }
    selected: list[dict[str, str]] = []
    selected_tags: set[str] = set()
    for index, raw_selector, selector_text in selectors:
        context = f"{product_id} runtime selector[{index}]"
        explicit_tag = raw_selector.get("tag")
        if explicit_tag is not None:
            if not isinstance(explicit_tag, str) or explicit_tag not in available_tags:
                raise ValueError(f"{context}: explicit Runtime tag is not published")
            values = [
                {
                    "runtime_tag": explicit_tag,
                    "version_text": explicit_tag,
                    "channel": "pinned",
                }
            ]
        else:
            selector_version = Version(selector_text)
            matching = [
                item
                for item in parsed_by_tag.values()
                if _version_is_in_selector(item["version"], selector_version)
            ]
            winners = _preferred_runtime_tags(matching)
            values = [
                item for item in winners if item["variant"] not in excluded_variants
            ]
            if not values:
                reason = (
                    "winning Runtime version contains only excluded variants"
                    if winners
                    else "no published Runtime tag matches the version range"
                )
                raise ValueError(f"{context}: {reason}")

        resolved_values = []
        for item in values:
            runtime_tag = str(item.get("runtime_tag", item.get("tag", "")))
            if not runtime_tag or runtime_tag in selected_tags:
                raise ValueError(f"{context}: Runtime tag is duplicated")
            selected_tags.add(runtime_tag)
            resolved_values.append(
                {
                    "runtime_tag": runtime_tag,
                    "version": str(item["version_text"]),
                    "channel": str(item["channel"]),
                }
            )
        selected.extend(sorted(resolved_values, key=lambda item: item["runtime_tag"]))
    return selected


def _blocked_problem(
    *, backend: str, capability: str, reason: str, repository: str, tag: str
) -> dict[str, object]:
    return {
        "backend": backend,
        "capability": capability,
        "reason": reason,
        "runtime": {"repository": repository, "tag": tag},
    }


def resolve_runtime_candidates(
    release: Mapping[str, object],
    *,
    tag_fixture: Mapping[str, object] | None = None,
    tag_loader: Callable[[str], Sequence[str]] | None = None,
    pr_default: bool = False,
    latest_per_product: Sequence[str] = (),
) -> dict[str, object]:
    """Select formal Runtime references strictly from published Registry tags.

    ``latest_per_product`` keeps only the newest numeric range for the named
    products. Every explicitly pinned Tag is retained.
    """

    products = release.get("products")
    if not isinstance(products, list) or not products:
        raise ValueError("formal runtime selection requires release products")
    backends = _mapping(release.get("backends"), "platform backends")
    excluded_by_product = _mapping(
        release.get("excluded_upstream_variants"), "excluded upstream variants"
    )
    latest_products = {str(item) for item in latest_per_product}
    known_products = {
        _string(_mapping(raw, "release product"), "id", "release product")
        for raw in products
    }
    unknown_products = sorted(latest_products - known_products)
    if unknown_products:
        raise ValueError(
            f"latest-per-product names unknown products: {unknown_products}"
        )
    runtimes: list[dict[str, str]] = []
    problems: list[dict[str, object]] = []
    for index, raw_product in enumerate(products):
        product = _mapping(raw_product, f"release products[{index}]")
        product_id = _string(product, "id", f"release products[{index}]")
        if pr_default and product_id != "vllm-ascend":
            continue
        if not pr_default and product.get("runtime_selectors") == []:
            continue
        repository = _string(product, "runtime_repository", product_id)
        excluded = excluded_by_product.get(product_id, [])
        if not isinstance(excluded, list) or not all(
            isinstance(item, str) for item in excluded
        ):
            raise ValueError(f"{product_id}: excluded variants must be a list")
        repository_tags = registry.repository_tags(
            repository, tag_fixture=tag_fixture, tag_loader=tag_loader
        )
        if pr_default:
            selected = [
                {
                    "runtime_tag": str(item["tag"]),
                    "version": str(item["version_text"]),
                    "channel": str(item["channel"]),
                }
                for tag in repository_tags
                if (item := _parsed_runtime_tag(product_id, tag)) is not None
                and item["variant"] not in excluded
                and not _is_sglang_runtime_variant(product_id, item)
            ]
        else:
            selected = _select_runtime_tags(
                product,
                repository_tags,
                excluded_variants=excluded,
                latest_only=product_id in latest_products,
            )
            selected = _without_sglang_runtime_tags(product_id, selected)
        if not selected:
            raise ValueError(
                f"{product_id}: no Runtime Registry tags satisfy the selection windows"
            )
        product_runtime_count = len(runtimes)
        for item in selected:
            tag = item["runtime_tag"]
            if item["channel"] != "pinned":
                parsed = _mapping(
                    _parsed_runtime_tag(product_id, tag),
                    f"selected Runtime tag {tag}",
                )
                backend = str(parsed["backend"])
                backend_policy = _mapping(backends.get(backend), f"backend {backend}")
                if backend_policy.get("status") == "blocked":
                    problems.append(
                        _blocked_problem(
                            backend=backend,
                            capability=f"{backend} runtime",
                            reason=str(backend_policy["reason"]),
                            repository=repository,
                            tag=tag,
                        )
                    )
                    continue
            candidate = {
                "product_id": product_id,
                "runtime_repository": repository,
                "runtime_tag": tag,
                "runtime_ref": f"{repository}:{tag}",
                "version": item["version"],
                "channel": item["channel"],
            }
            runtimes.append(candidate)
        if len(runtimes) == product_runtime_count:
            raise ValueError(
                f"{product_id}: no publishable Runtime Registry tags satisfy policy"
            )
    if pr_default:
        eligible = []
        for item in runtimes:
            if item["product_id"] != "vllm-ascend":
                continue
            parsed = _parsed_runtime_tag("vllm-ascend", item["runtime_tag"])
            if parsed is not None and not parsed["tokens"]:
                eligible.append(item)
        preferred = _preferred_runtime_tags(eligible)
        if not preferred:
            raise ValueError("PR default selector found no Ascend A2 Ubuntu Runtime")
        selected_default = max(
            preferred,
            key=lambda item: str(item["runtime_tag"]),
        )
        runtimes = [selected_default]
        problems = []

    document = {
        "kind": CANDIDATES_KIND,
        "schema_version": CANDIDATES_SCHEMA_VERSION,
        "runtimes": sorted(
            runtimes, key=lambda item: (item["product_id"], item["runtime_tag"])
        ),
        "references": sorted(item["runtime_ref"] for item in runtimes),
        "problems": sorted(
            problems,
            key=lambda item: (
                str(item["backend"]),
                str(item["runtime"]["repository"]),
                str(item["runtime"]["tag"]),
            ),
        ),
    }
    return validate_runtime_candidates(document)


def validate_runtime_candidates(value: object) -> dict[str, object]:
    document = _mapping(value, "runtime candidates")
    expected = {"kind", "schema_version", "runtimes", "references", "problems"}
    if set(document) != expected:
        raise ValueError("runtime candidates fields must be exact")
    if (
        document.get("kind") != CANDIDATES_KIND
        or document.get("schema_version") != CANDIDATES_SCHEMA_VERSION
    ):
        raise ValueError("runtime candidates contract is unsupported")
    runtimes = document.get("runtimes")
    references = document.get("references")
    problems = document.get("problems")
    if not isinstance(runtimes, list) or not runtimes:
        raise ValueError("runtime candidates must contain runtimes")
    if not isinstance(references, list) or not all(
        isinstance(item, str) for item in references
    ):
        raise ValueError("runtime candidate references must be a string list")
    expected_refs: list[str] = []
    seen: set[str] = set()
    for index, raw in enumerate(runtimes):
        item = _mapping(raw, f"runtime candidates[{index}]")
        product_id = _string(item, "product_id", f"runtime candidates[{index}]")
        runtime_tag = _string(item, "runtime_tag", f"runtime candidates[{index}]")
        fields = {
            "product_id",
            "runtime_repository",
            "runtime_tag",
            "runtime_ref",
            "version",
            "channel",
        }
        if set(item) != fields:
            raise ValueError(f"runtime candidates[{index}] fields must be exact")
        reference = _string(item, "runtime_ref", f"runtime candidates[{index}]")
        expected_ref = (
            f"{_string(item, 'runtime_repository', reference)}:"
            f"{_string(item, 'runtime_tag', reference)}"
        )
        if reference != expected_ref:
            raise ValueError(
                f"{reference}: runtime candidate reference is inconsistent"
            )
        if reference in seen:
            raise ValueError(f"duplicate runtime candidate {reference}")
        seen.add(reference)
        if item.get("channel") == "pinned":
            if product_id not in version_config.SUPPORTED_VERSION_KEYS:
                raise ValueError(
                    f"{reference}: unsupported runtime product {product_id!r}"
                )
            runtime_contract.parse_runtime_reference(reference)
            if item.get("version") != runtime_tag:
                raise ValueError(
                    f"{reference}: pinned Runtime version must equal its tag"
                )
        else:
            parsed = _parsed_runtime_tag(product_id, runtime_tag)
            if parsed is None:
                raise ValueError(
                    f"{reference}: Runtime tag does not match product grammar"
                )
            if item.get("version") != parsed["version_text"]:
                raise ValueError(f"{reference}: Runtime version differs from its tag")
            if item.get("channel") != parsed["channel"]:
                raise ValueError(f"{reference}: Runtime channel differs from its tag")
        expected_refs.append(reference)
    if sorted(references) != sorted(expected_refs):
        raise ValueError("runtime candidate references do not match runtimes")
    _validate_problems(problems)
    return document


def _runtime_probe_document(value: object) -> list[dict[str, Any]]:
    document = _mapping(value, "runtime probe")
    if (
        document.get("kind") != "ucm-runtime-probe"
        or document.get("schema_version")
        != runtime_contract.RUNTIME_PROBE_SCHEMA_VERSION
    ):
        raise ValueError("runtime probe has an unsupported contract")
    values = document.get("probes")
    if not isinstance(values, list) or not values:
        raise ValueError("runtime probe must contain probes")
    return [
        _mapping(item, f"runtime probes[{index}]") for index, item in enumerate(values)
    ]


def resolve_upstreams(
    release: Mapping[str, object],
    *,
    candidates: Mapping[str, object] | None = None,
    runtime_probe: Mapping[str, object] | None = None,
    tag_fixture: Mapping[str, object] | None = None,
    tag_loader: Callable[[str], Sequence[str]] | None = None,
    manifest_loader: Callable[[str], object] | None = None,
    config_loader: Callable[[str], object] | None = None,
    digest_loader: Callable[[str], str] | None = None,
) -> dict[str, object]:
    """Resolve probed Registry runtimes into the formal Wheel union."""

    selected = validate_runtime_candidates(
        candidates
        if candidates is not None
        else resolve_runtime_candidates(
            release, tag_fixture=tag_fixture, tag_loader=tag_loader
        )
    )
    if runtime_probe is None and tag_fixture is not None:
        fixture_probe = tag_fixture.get("runtime_probe")
        if isinstance(fixture_probe, Mapping):
            runtime_probe = fixture_probe
    if runtime_probe is None:
        raise ValueError(
            "formal Registry selection requires per-member runtime probe results"
        )
    probes = _runtime_probe_document(runtime_probe)
    candidate_by_ref = {
        str(item["runtime_ref"]): item
        for item in selected["runtimes"]  # type: ignore[index]
    }
    observed_refs = {str(probe.get("runtime_ref")) for probe in probes}
    missing = sorted(set(candidate_by_ref) - observed_refs)
    extra = sorted(observed_refs - set(candidate_by_ref))
    if missing or extra:
        raise ValueError(
            f"runtime probes differ from candidates: missing={missing}, extra={extra}"
        )

    backend_policies = _mapping(release.get("backends"), "platform backends")
    excluded_by_product = _mapping(
        release.get("excluded_upstream_variants"), "excluded upstream variants"
    )
    # An opaque pin's platform comes from the inspected image, not its name.
    for probe in probes:
        reference = str(probe["runtime_ref"])
        if candidate_by_ref[reference]["channel"] != "pinned":
            continue
        backend = str(probe["backend"])
        backend_policy = _mapping(backend_policies.get(backend), f"backend {backend}")
        if backend_policy.get("status") == "blocked":
            raise ValueError(
                f"{reference}: probed Runtime backend {backend} is blocked: "
                f"{backend_policy.get('reason', '')}"
            )
        _, variant, _ = runtime_contract.wheel_variant(probe)
        excluded = excluded_by_product.get(probe["product_id"], [])
        if variant in excluded:
            raise ValueError(
                f"{reference}: probed Runtime variant {variant} is excluded"
            )

    wheel_builds = builders.resolve_probe_builds(
        release,
        probes,
        tag_fixture=tag_fixture,
        tag_loader=tag_loader,
        manifest_loader=manifest_loader,
        config_loader=config_loader,
        digest_loader=digest_loader,
    )
    builds_by_capability = {
        (
            str(build["backend"]),
            str(build["accelerator_runtime"]),
            str(build["soc_version"]),
            str(build["python_abi"]),
            str(build["cpu_arch"]),
        ): build
        for build in wheel_builds
    }
    grouped: dict[str, list[dict[str, Any]]] = {}
    for probe in probes:
        grouped.setdefault(_string(probe, "runtime_ref", "runtime probe"), []).append(
            probe
        )

    products = {
        str(item["id"]): _mapping(item, "release product")
        for item in release["products"]  # type: ignore[index]
    }
    runtimes: list[dict[str, object]] = []
    for reference, group in sorted(grouped.items()):
        candidate = candidate_by_ref[reference]
        first = group[0]
        invariant_fields = (
            "product_id",
            "repository",
            "tag",
            "runtime_digest",
            "backend",
            "accelerator_runtime",
            "soc_version",
            "python_version",
            "python_abi",
            "os_id",
            "os_version",
            "glibc_version",
        )
        for field in invariant_fields:
            if len({str(item.get(field, "")) for item in group}) != 1:
                raise ValueError(f"{reference}: Runtime members disagree on {field}")
        product_id = _string(first, "product_id", reference)
        product = products[product_id]
        _, variant, runtime_variant = runtime_contract.wheel_variant(first)
        architectures = sorted(_string(item, "cpu_arch", reference) for item in group)
        if len(set(architectures)) != len(architectures):
            raise ValueError(f"{reference}: duplicate probed architecture")
        member_references = {
            _string(item, "cpu_arch", reference): _string(
                item, "image_reference", reference
            )
            for item in group
        }
        wheel_ids: dict[str, str] = {}
        for item in group:
            key = (
                str(item["backend"]),
                str(item["accelerator_runtime"]),
                str(item["soc_version"]),
                str(item["python_abi"]),
                str(item["cpu_arch"]),
            )
            build = builds_by_capability.get(key)
            if build is None:
                raise ValueError(f"{reference}: no Wheel build for {key}")
            wheel_ids[str(item["cpu_arch"])] = str(build["id"])
        tag = _string(first, "tag", reference)
        runtime_id = re.sub(r"[^a-z0-9._-]+", "-", f"{product_id}-{tag}".lower()).strip(
            ".-"
        )
        if candidate["channel"] == "pinned":
            # OCI Tags are case-sensitive, while task IDs must be lowercase.
            runtime_id = (
                f"{product_id}-pin-{hashlib.sha256(tag.encode()).hexdigest()[:16]}"
            )
        image_suffix = (
            f"-ucm-{runtime_contract.oci_tag_version(str(release['ucm_version']))}"
        )
        target_tag = runtime_contract.project_runtime_image_tag(
            tag + image_suffix,
            tag_prefix=str(release.get("runtime_image_tag_prefix", "")),
            architectures=architectures,
        )
        runtimes.append(
            {
                "id": runtime_id,
                "product_id": product_id,
                "runtime_repository": _string(first, "repository", reference),
                "runtime_tag": tag,
                "runtime_digest": _string(first, "runtime_digest", reference),
                "runtime_variant": runtime_variant,
                "backend": _string(first, "backend", reference),
                "accelerator_runtime": _string(first, "accelerator_runtime", reference),
                "variant": variant,
                "soc_version": _string(first, "soc_version", reference),
                "python_version": _string(first, "python_version", reference),
                "python_abi": _string(first, "python_abi", reference),
                "os_id": _string(first, "os_id", reference),
                "os_version": _string(first, "os_version", reference),
                "glibc_version": first.get("glibc_version"),
                "architectures": architectures,
                "member_references": member_references,
                "wheel_build_ids": wheel_ids,
                "version": candidate["version"],
                "channel": candidate["channel"],
                "target_repository": product["target_repository"],
                "target_tag": target_tag,
            }
        )
    return validate_selection(
        {
            "kind": SELECTION_KIND,
            "schema_version": SELECTION_SCHEMA_VERSION,
            "wheel_builds": wheel_builds,
            "runtimes": runtimes,
            "problems": copy.deepcopy(selected["problems"]),
        }
    )


def _validate_problems(value: object) -> None:
    if not isinstance(value, list):
        raise ValueError("problems must be a list")
    seen: set[bytes] = set()
    for index, raw in enumerate(value):
        problem = _mapping(raw, f"problems[{index}]")
        if set(problem) != _PROBLEM_FIELDS:
            raise ValueError(f"problems[{index}] fields must be exact")
        for field in ("backend", "capability", "reason"):
            _string(problem, field, f"problems[{index}]")
        runtime = _mapping(problem.get("runtime"), f"problems[{index}].runtime")
        if set(runtime) != {"repository", "tag"}:
            raise ValueError(f"problems[{index}].runtime fields must be exact")
        _string(runtime, "repository", f"problems[{index}].runtime")
        _string(runtime, "tag", f"problems[{index}].runtime")
        identity = serialization.canonical_bytes(problem)
        if identity in seen:
            raise ValueError(f"duplicate problem at index {index}")
        seen.add(identity)


def validate_selection(value: object) -> dict[str, object]:
    selection = _mapping(value, "runtime selection")
    expected = {
        "kind",
        "schema_version",
        "wheel_builds",
        "runtimes",
        "problems",
    }
    if set(selection) != expected:
        raise ValueError("runtime selection fields must be exact")
    if (
        selection.get("kind") != SELECTION_KIND
        or selection.get("schema_version") != SELECTION_SCHEMA_VERSION
    ):
        raise ValueError("runtime selection contract is unsupported")
    builds = selection.get("wheel_builds")
    runtimes = selection.get("runtimes")
    if not isinstance(builds, list) or not builds:
        raise ValueError("runtime selection wheel_builds must be non-empty")
    if not isinstance(runtimes, list) or not runtimes:
        raise ValueError("runtime selection runtimes must be non-empty")
    build_ids: set[str] = set()
    for index, raw in enumerate(builds):
        build = _mapping(raw, f"wheel_builds[{index}]")
        if set(build) != _WHEEL_BUILD_FIELDS:
            raise ValueError(f"wheel_builds[{index}] fields must be exact")
        build_id = _string(build, "id", f"wheel_builds[{index}]")
        if build_id in build_ids:
            raise ValueError(f"duplicate Wheel build {build_id}")
        build_ids.add(build_id)
        if build.get("cpu_arch") not in SUPPORTED_ARCHITECTURES:
            raise ValueError(f"{build_id}: unsupported cpu_arch")
        if build.get("build_mode") != "mirror":
            raise ValueError(f"{build_id}: build_mode must be mirror")
        if build.get("sync_mode") != "mirror":
            raise ValueError(f"{build_id}: sync_mode is invalid")
        if re.fullmatch(r"cp[0-9]+", str(build.get("python_abi"))) is None:
            raise ValueError(f"{build_id}: malformed python_abi")
        if _DIGEST.fullmatch(str(build.get("source_image_digest"))) is None:
            raise ValueError(f"{build_id}: malformed source_image_digest")
        if re.fullmatch(r"[0-9a-f]{12}", str(build.get("recipe_revision"))) is None:
            raise ValueError(f"{build_id}: malformed recipe_revision")
    runtime_ids: set[str] = set()
    coordinates: set[tuple[str, str]] = set()
    targets: set[tuple[str, str]] = set()
    for index, raw in enumerate(runtimes):
        runtime = _mapping(raw, f"runtimes[{index}]")
        if set(runtime) != _RUNTIME_FIELDS:
            raise ValueError(f"runtimes[{index}] fields must be exact")
        runtime_id = _string(runtime, "id", f"runtimes[{index}]")
        if (
            runtime_id in runtime_ids
            or re.fullmatch(r"[a-z0-9][a-z0-9._-]*", runtime_id) is None
        ):
            raise ValueError(f"duplicate or malformed runtime {runtime_id!r}")
        runtime_ids.add(runtime_id)
        coordinate = (
            _string(runtime, "runtime_repository", runtime_id),
            _string(runtime, "runtime_tag", runtime_id),
        )
        target = (
            _string(runtime, "target_repository", runtime_id),
            _string(runtime, "target_tag", runtime_id),
        )
        if coordinate in coordinates or target in targets:
            raise ValueError(f"{runtime_id}: duplicate runtime or target coordinate")
        coordinates.add(coordinate)
        targets.add(target)
        if _DIGEST.fullmatch(_string(runtime, "runtime_digest", runtime_id)) is None:
            raise ValueError(f"{runtime_id}: malformed runtime_digest")
        supported_channels = {"stable", "rc", "pinned"}
        if runtime.get("product_id") != "sglang":
            supported_channels.add("nightly")
        if runtime.get("channel") not in supported_channels:
            raise ValueError(f"{runtime_id}: unsupported runtime channel")
        architectures = runtime.get("architectures")
        wheel_ids = runtime.get("wheel_build_ids")
        members = runtime.get("member_references")
        if (
            not isinstance(architectures, list)
            or not architectures
            or len(set(architectures)) != len(architectures)
            or not set(architectures) <= set(SUPPORTED_ARCHITECTURES)
        ):
            raise ValueError(f"{runtime_id}: invalid architectures")
        if not isinstance(wheel_ids, Mapping) or set(wheel_ids) != set(architectures):
            raise ValueError(f"{runtime_id}: wheel_build_ids must match architectures")
        if not isinstance(members, Mapping) or set(members) != set(architectures):
            raise ValueError(
                f"{runtime_id}: member_references must match architectures"
            )
        if any(str(value) not in build_ids for value in wheel_ids.values()):
            raise ValueError(f"{runtime_id}: unknown Wheel build")
        if not all(
            isinstance(value, str) and "@sha256:" in value for value in members.values()
        ):
            raise ValueError(f"{runtime_id}: member references must be digest-pinned")
    _validate_problems(selection.get("problems"))
    return selection
