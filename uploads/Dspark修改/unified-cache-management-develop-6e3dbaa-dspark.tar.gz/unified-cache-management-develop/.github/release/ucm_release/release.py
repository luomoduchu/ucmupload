"""Build staged Release state and the public install and cleanup manifest."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlparse

if __package__:
    from . import manifest as public_manifest
    from . import release_body, runtime, toolkit, wheel_audit
else:
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    import manifest as public_manifest
    import release_body
    import runtime
    import wheel_audit
    from ucm_release import toolkit

_DIGEST = re.compile(r"sha256:[0-9a-f]{64}")
STATE_KIND = "ucm-release-state"
STATE_SCHEMA_VERSION = 3


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _mapping(value: object, context: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{context} must be a JSON object")
    return value


def _list(value: object, context: str) -> list[Any]:
    if not isinstance(value, list):
        raise ValueError(f"{context} must be a JSON array")
    return value


def _one(paths: list[Path], context: str) -> Path:
    if len(paths) != 1:
        raise ValueError(f"{context} must resolve exactly once, found {len(paths)}")
    return paths[0]


def _validate_wheel_result_contract(result: dict[str, Any], result_path: Path) -> None:
    context = f"Wheel result {result_path}"
    if result.get("kind") != "ucm-wheel-result" or result.get("schema_version") != 5:
        raise ValueError(f"{context} must use ucm-wheel-result schema 5")

    audit_fields = {
        "platform_tags",
        "auditwheel_platform_tag",
        "abi_compatible_platform_tag",
        "glibc_versions",
        "glibc_floor",
        "external_library_roots",
        "external_libraries",
        "deferred_external_libraries",
        "auditwheel_report",
        "repair",
        "sha256",
        "dependencies",
    }
    missing_fields = sorted(audit_fields - result.keys())
    if missing_fields:
        raise ValueError(f"{context} is missing audit fields: {missing_fields}")
    if "runtime_deferred_libraries" in result:
        raise ValueError(f"{context} contains removed field runtime_deferred_libraries")

    platform_tags = result.get("platform_tags")
    if (
        not isinstance(platform_tags, list)
        or not platform_tags
        or any(not isinstance(value, str) or not value for value in platform_tags)
    ):
        raise ValueError(f"{context} has invalid platform_tags")
    auditwheel_platform = result.get("auditwheel_platform_tag")
    if not isinstance(auditwheel_platform, str) or not auditwheel_platform:
        raise ValueError(f"{context} has no auditwheel_platform_tag")
    abi_platform = result.get("abi_compatible_platform_tag")
    if not isinstance(abi_platform, str) or not abi_platform.startswith("manylinux_"):
        raise ValueError(f"{context} has no manylinux ABI compatibility tag")
    digest = result.get("sha256")
    if not isinstance(digest, str) or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
        raise ValueError(f"{context} has an invalid Wheel digest")
    dependencies = result.get("dependencies")
    if not isinstance(dependencies, list) or any(
        not isinstance(value, str) or not value for value in dependencies
    ):
        raise ValueError(f"{context} has invalid dependencies")

    glibc_versions = result.get("glibc_versions")
    if not isinstance(glibc_versions, list) or any(
        not isinstance(value, str) or not value for value in glibc_versions
    ):
        raise ValueError(f"{context} has invalid glibc_versions")
    glibc_floor = result.get("glibc_floor")
    if glibc_floor is not None and (
        not isinstance(glibc_floor, str) or glibc_floor not in glibc_versions
    ):
        raise ValueError(f"{context} has an invalid glibc_floor")
    external_roots = result.get("external_library_roots")
    external_libraries = result.get("external_libraries")
    if not isinstance(external_libraries, list) or any(
        not isinstance(value, str) or not value for value in external_libraries
    ):
        raise ValueError(f"{context} has invalid external_libraries")
    if external_libraries != sorted(set(external_libraries)):
        raise ValueError(f"{context} has non-canonical external_libraries")
    if (
        not isinstance(external_roots, list)
        or external_roots != sorted(set(external_roots))
        or any(not isinstance(value, str) or not value for value in external_roots)
        or not set(external_roots).issubset(external_libraries)
    ):
        raise ValueError(f"{context} has invalid external_library_roots")
    deferred_external = result.get("deferred_external_libraries")
    if (
        not isinstance(deferred_external, list)
        or deferred_external != sorted(set(deferred_external))
        or any(not isinstance(value, str) or not value for value in deferred_external)
        or not set(deferred_external).issubset(external_libraries)
        or set(deferred_external).intersection(external_roots)
    ):
        raise ValueError(f"{context} has invalid deferred_external_libraries")
    for soname in deferred_external:
        wheel_audit.validate_external_soname(soname)

    repair = _mapping(result.get("repair"), f"{context} repair")
    if set(repair) != {
        "tool",
        "version",
        "target_platform",
        "excluded_patterns",
    }:
        raise ValueError(f"{context} has an invalid repair contract")
    if repair.get("tool") != "auditwheel" or not isinstance(repair.get("version"), str):
        raise ValueError(f"{context} has an invalid repair tool")
    target_platform = repair.get("target_platform")
    if not isinstance(target_platform, str) or target_platform not in platform_tags:
        raise ValueError(f"{context} repair target is not a Wheel platform tag")
    excluded = repair.get("excluded_patterns")
    if (
        not isinstance(excluded, list)
        or excluded != sorted(excluded)
        or len(excluded) != len(set(excluded))
        or any(not isinstance(value, str) or not value for value in excluded)
    ):
        raise ValueError(f"{context} has invalid external exclude patterns")

    report = _mapping(result.get("auditwheel_report"), f"{context} auditwheel report")
    report_name = report.get("filename")
    if (
        not isinstance(report_name, str)
        or not report_name
        or report_name in {".", ".."}
        or Path(report_name).name != report_name
    ):
        raise ValueError(f"{context} has an invalid auditwheel report filename")
    report_path = result_path.parent / report_name
    if not report_path.is_file():
        raise ValueError(f"{context} has no matching auditwheel report file")
    report_digest = report.get("sha256")
    report_text = report.get("text")
    if not isinstance(report_digest, str) or _sha256(report_path) != report_digest:
        raise ValueError(f"{context} auditwheel report digest does not match")
    if (
        not isinstance(report_text, str)
        or report_path.read_text(encoding="utf-8") != report_text
    ):
        raise ValueError(f"{context} auditwheel report text does not match")
    closure = wheel_audit.validate_external_library_closure(
        report_text,
        expected_patterns=excluded,
        deferred_sonames=wheel_audit.deferred_policy_for_distribution(
            str(result.get("distribution", ""))
        ),
    )
    if external_roots != closure["external_library_roots"]:
        raise ValueError(f"{context} external roots do not match auditwheel")
    if external_libraries != closure["external_libraries"]:
        raise ValueError(f"{context} external libraries do not match auditwheel")
    if deferred_external != closure["deferred_external_libraries"]:
        raise ValueError(f"{context} deferred libraries do not match auditwheel")


def _family_map(plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    families = {
        str(item["id"]): _mapping(item, "release plan family")
        for item in _list(plan.get("families"), "release plan families")
    }
    if len(families) != len(plan["families"]):
        raise ValueError("release plan family IDs must be unique")
    return families


def _meta_artifact(
    plan: dict[str, Any], meta_root: Path | None
) -> tuple[dict[str, Any] | None, Path | None]:
    planned = plan.get("meta_package")
    if planned is None:
        if meta_root is not None and any(meta_root.rglob("*")):
            raise ValueError(
                "meta artifacts were provided without a planned meta package"
            )
        return None, None
    if meta_root is None:
        raise ValueError("planned meta package has no artifact directory")
    planned_meta = _mapping(planned, "release plan meta package")
    result_path = _one(sorted(meta_root.rglob("meta-result.json")), "meta result")
    result = _mapping(_load_json(result_path), f"meta result {result_path}")
    if result.get("kind") != "ucm-meta-result" or result.get("schema_version") != 1:
        raise ValueError("meta result must use ucm-meta-result schema 1")
    expected = {
        "distribution": planned_meta.get("distribution"),
        "version": planned_meta.get("version"),
        "extras": planned_meta.get("extras"),
        "tags": ["py3-none-any"],
    }
    if any(result.get(key) != value for key, value in expected.items()):
        raise ValueError("meta result does not match the release plan")
    filename = result.get("filename")
    if not isinstance(filename, str) or not filename:
        raise ValueError("meta result has no filename")
    wheel_path = result_path.parent / filename
    if not wheel_path.is_file():
        raise ValueError("meta result has no matching Wheel")
    digest = result.get("sha256")
    if digest != f"sha256:{_sha256(wheel_path)}":
        raise ValueError("meta result digest does not match its Wheel")
    discovered = {path.resolve() for path in meta_root.rglob("*.whl")}
    if discovered != {wheel_path.resolve()}:
        raise ValueError("meta Wheel files and result must match exactly")
    return copy.deepcopy(result), wheel_path


def build_release_state(
    plan: dict[str, Any],
    wheels_root: Path,
    chart_root: Path,
    meta_root: Path | None = None,
    *,
    toolkit_root: Path | None = None,
    actions_run_id: int,
) -> tuple[dict[str, Any], list[tuple[str, str]]]:
    """Validate planned artifacts and return release state plus checksums.

    The Chart OCI publication flag controls whether Chart outputs are required.
    Plans always retain Chart metadata, even when no Chart artifact is built.
    """
    tasks = {
        str(item["id"]): _mapping(item, "release plan Wheel")
        for item in _list(plan.get("wheels"), "release plan Wheels")
    }
    if len(tasks) != len(plan["wheels"]):
        raise ValueError("release plan Wheel IDs must be unique")

    results: dict[str, dict[str, Any]] = {}
    wheel_files: dict[str, Path] = {}
    for result_path in sorted(wheels_root.rglob("wheel-result.json")):
        result = _mapping(_load_json(result_path), f"Wheel result {result_path}")
        _validate_wheel_result_contract(result, result_path)
        task_id = str(result.get("task_id", ""))
        if task_id not in tasks or task_id in results:
            raise ValueError(f"Wheel result {task_id!r} is unknown or duplicated")
        filename = str(result.get("filename", ""))
        wheel_path = result_path.parent / filename
        if not filename or not wheel_path.is_file():
            raise ValueError(f"Wheel result {task_id!r} has no matching file")
        if _sha256(wheel_path) != result["sha256"]:
            raise ValueError(f"Wheel result {task_id!r} digest does not match its file")
        task = tasks[task_id]
        expected = {
            "distribution": task["dist_name"],
            "version": task["wheel_version"],
            "python_abi": task["python_abi"],
            "cpu_arch": task["cpu_arch"],
            "dependencies": task["runtime_requirements"],
        }
        if any(result.get(key) != value for key, value in expected.items()):
            raise ValueError(f"Wheel result {task_id!r} does not match its plan")
        expected_repair = {
            "tool": task["repair"]["tool"],
            "version": task["repair"]["version"],
            "target_platform": task["target_platform_tag"],
            "excluded_patterns": task["external_runtime_exclude_patterns"],
        }
        if result.get("repair") != expected_repair:
            raise ValueError(f"Wheel result {task_id!r} repair does not match its plan")
        results[task_id] = result
        wheel_files[task_id] = wheel_path

    if set(results) != set(tasks):
        missing = sorted(set(tasks) - set(results))
        raise ValueError(f"Wheel results do not cover the plan: {missing}")
    discovered_wheels = {path.resolve() for path in wheels_root.rglob("*.whl")}
    declared_wheels = {path.resolve() for path in wheel_files.values()}
    if discovered_wheels != declared_wheels:
        raise ValueError("Wheel files and result manifests must match exactly")
    filenames = [str(item["filename"]) for item in results.values()]
    if len(filenames) != len(set(filenames)):
        raise ValueError("Wheel result filenames must be unique")

    meta_result, meta_wheel_path = _meta_artifact(plan, meta_root)
    toolkit_result, toolkit_wheel_path = toolkit.load_artifact(plan, toolkit_root)
    publish = copy.deepcopy(_mapping(plan.get("publish"), "release plan publish"))
    chart_oci = _mapping(publish.get("chart_oci"), "release plan Chart OCI")
    chart_path = (
        _one(sorted(chart_root.rglob("*.tgz")), "Chart package")
        if chart_oci.get("enabled") is True
        else None
    )
    checksums: list[tuple[str, str]] = []
    wheels: list[dict[str, Any]] = []
    for task_id in sorted(results):
        result = copy.deepcopy(results[task_id])
        task = tasks[task_id]
        digest = _sha256(wheel_files[task_id])
        result["id"] = result.pop("task_id")
        result["sha256"] = digest
        result["backend"] = task["backend"]
        result["runtime_variant"] = task["runtime_variant"]
        result["manylinux_builder"] = task["manylinux"]
        builder = _mapping(task.get("builder"), f"Wheel task {task_id} Builder")
        if (
            not isinstance(builder.get("digest"), str)
            or _DIGEST.fullmatch(builder["digest"]) is None
        ):
            raise ValueError(f"Wheel task {task_id} has no immutable Builder digest")
        result["builder"] = copy.deepcopy(builder)
        wheels.append(result)
        checksums.append((digest, str(result["filename"])))

    if chart_path is not None:
        chart_digest = _sha256(chart_path)
        checksums.append((chart_digest, chart_path.name))
    if meta_result is not None and meta_wheel_path is not None:
        checksums.append((_sha256(meta_wheel_path), str(meta_result["filename"])))
    if toolkit_result is not None:
        checksums.append((_sha256(toolkit_wheel_path), toolkit_result["filename"]))
    families = _family_map(plan)
    images = []
    for raw in _list(plan.get("images"), "release plan Images"):
        item = _mapping(raw, "release plan Image")
        family = families.get(str(item["family_id"]))
        if family is None:
            raise ValueError(f"Image {item.get('id')!r} has no release family")
        member = _one(
            [
                value
                for value in family["members"]
                if value.get("image_id") == item.get("id")
            ],
            f"Image {item.get('id')!r} family member",
        )
        expected_targets = runtime.image_publication_targets(plan, member["reference"])
        images.append(
            {
                "id": item["id"],
                "family_id": item["family_id"],
                "wheel_id": item["wheel_id"],
                "cpu_arch": item["cpu_arch"],
                "runtime": copy.deepcopy(item["runtime"]),
                "planned_reference": member["reference"],
                "expected_targets": expected_targets,
                "status": "building" if expected_targets else "not-requested",
                "targets": [],
            }
        )

    family_records = []
    for family in sorted(families.values(), key=lambda item: str(item["id"])):
        expected_targets = runtime.image_publication_targets(
            plan, family["published_reference"]
        )
        family_records.append(
            {
                "id": family["id"],
                "runtime": copy.deepcopy(family["runtime"]),
                "planned_reference": family["published_reference"],
                "expected_targets": expected_targets,
                "create_index": family["create_index"],
                "status": "building" if expected_targets else "not-requested",
                "targets": [],
            }
        )
    publication_requested = any(
        item["expected_targets"] for item in [*images, *family_records]
    ) or any(
        _mapping(publish.get(channel), f"release plan {channel}").get("enabled") is True
        for channel in ("pypi", "chart_oci")
    )
    if isinstance(actions_run_id, bool) or actions_run_id < 1:
        raise ValueError("Actions run ID must be a positive integer")
    chart = None
    if chart_path is not None:
        chart = {
            "name": plan["chart"]["name"],
            "version": plan["chart"]["version"],
            "app_version": plan["chart"]["app_version"],
            "filename": chart_path.name,
            "sha256": chart_digest,
            "oci_reference": (
                f"{chart_oci['namespace']}/{plan['chart']['name']}:{plan['chart']['version']}"
            ),
        }
    manifest = {
        "kind": STATE_KIND,
        "schema_version": STATE_SCHEMA_VERSION,
        "publish": publish,
        "release": {
            "git_tag": plan["git_tag"],
            "release_type": plan["release_type"],
            "release_kind": plan.get("release_kind", "publish"),
            "is_prerelease": plan.get("is_prerelease", True),
            "version": plan["version"],
            "actions_run_id": actions_run_id,
            "status": "artifacts-ready" if publication_requested else "complete",
        },
        "chart": chart,
        "wheels": wheels,
        "images": sorted(images, key=lambda item: str(item["id"])),
        "families": family_records,
    }
    if meta_result is not None:
        manifest["meta_package"] = meta_result
    if toolkit_result is not None:
        manifest["toolkit_package"] = toolkit_result
    return manifest, sorted(checksums, key=lambda item: item[1])


def _receipt_map(receipts_root: Path, kind: str) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    if not receipts_root.exists():
        return result
    for path in sorted(receipts_root.rglob("*.json")):
        receipt = _mapping(_load_json(path), f"publication receipt {path}")
        if receipt.get("kind") != kind:
            continue
        if receipt.get("schema_version") != 1 or set(receipt) != {
            "kind",
            "schema_version",
            "id",
            "status",
            "targets",
        }:
            raise ValueError(f"publication receipt {path} has an invalid contract")
        identity = str(receipt.get("id", ""))
        if not identity or identity in result:
            raise ValueError(
                f"publication receipt {identity!r} is missing or duplicated"
            )
        result[identity] = receipt
    return result


def _validated_receipt_targets(
    receipt: dict[str, Any], expected: object, context: str
) -> list[dict[str, str]]:
    expected_targets = _mapping(expected, f"{context} expected targets")
    if receipt.get("status") not in {"published", "failed"}:
        raise ValueError(f"{context} has an invalid status")
    raw_targets = _list(receipt.get("targets"), f"{context} targets")
    targets: list[dict[str, str]] = []
    observed: dict[str, str] = {}
    for index, raw_target in enumerate(raw_targets):
        target = _mapping(raw_target, f"{context} targets[{index}]")
        if set(target) != {"channel", "reference", "digest"}:
            raise ValueError(f"{context} target fields must be exact")
        channel = target.get("channel")
        reference = target.get("reference")
        digest = target.get("digest")
        if (
            not isinstance(channel, str)
            or channel in observed
            or channel not in expected_targets
        ):
            raise ValueError(f"{context} has an unexpected or duplicate channel")
        if not isinstance(reference, str) or reference != expected_targets[channel]:
            raise ValueError(f"{context} target does not match its planned reference")
        if not isinstance(digest, str) or _DIGEST.fullmatch(digest) is None:
            raise ValueError(f"{context} target digest is invalid")
        observed[channel] = reference
        targets.append({"channel": channel, "reference": reference, "digest": digest})
    if receipt["status"] == "published" and set(observed) != set(expected_targets):
        raise ValueError(f"{context} does not cover its expected publication targets")
    return targets


def validate_member_receipts(
    plan: dict[str, Any], receipts_root: Path
) -> dict[str, dict[str, Any]]:
    """Require one complete member receipt for every planned image."""
    families = _family_map(plan)
    expected: dict[str, dict[str, str]] = {}
    for raw_image in _list(plan.get("images"), "release plan Images"):
        image = _mapping(raw_image, "release plan Image")
        image_id = str(image.get("id", ""))
        family = families.get(str(image.get("family_id", "")))
        if not image_id or family is None:
            raise ValueError("release plan Image has no family")
        member = _one(
            [
                item
                for item in _list(family.get("members"), "release family members")
                if _mapping(item, "release family member").get("image_id") == image_id
            ],
            f"Image {image_id!r} family member",
        )
        expected[image_id] = runtime.image_publication_targets(
            plan, str(member["reference"])
        )
    receipts = _receipt_map(receipts_root, "ucm-image-member-receipt")
    if set(receipts) != set(expected):
        raise ValueError("member receipts do not exactly cover planned Images")
    for image_id, receipt in receipts.items():
        _validated_receipt_targets(
            receipt, expected[image_id], f"Image {image_id} receipt"
        )
        if receipt.get("status") != "published":
            raise ValueError(f"Image {image_id} receipt is not published")
    return receipts


def _pypi_receipt(receipts_root: Path) -> dict[str, Any] | None:
    matches: list[dict[str, Any]] = []
    if receipts_root.exists():
        for path in sorted(receipts_root.rglob("*.json")):
            value = _mapping(_load_json(path), f"publication receipt {path}")
            if value.get("kind") == "ucm-pypi-receipt":
                matches.append(value)
    if len(matches) > 1:
        raise ValueError("PyPI publication receipt is duplicated")
    if not matches:
        return None
    return public_manifest.validate_pypi_receipt(matches[0])


def finalize_release_state(
    manifest: dict[str, Any],
    receipts_root: Path,
    *,
    build_outcome: str,
    member_outcome: str,
    index_outcome: str,
    pypi_outcome: str = "skipped",
    pypi_install_outcome: str = "skipped",
    chart_oci_outcome: str = "success",
) -> dict[str, Any]:
    """Merge immutable publication receipts and close the image stage."""
    result = copy.deepcopy(manifest)
    members = _receipt_map(receipts_root, "ucm-image-member-receipt")
    indexes = _receipt_map(receipts_root, "ucm-image-index-receipt")
    expected_image_ids = {str(item["id"]) for item in result["images"]}
    expected_index_ids = {
        str(item["id"]) for item in result["families"] if item["create_index"]
    }
    if set(members) - expected_image_ids:
        raise ValueError("member receipts contain unknown Image IDs")
    if set(indexes) - expected_index_ids:
        raise ValueError("index receipts contain unknown family IDs")
    publish_contract = result.get("publish")
    planned_pypi = (
        _mapping(publish_contract.get("pypi"), "release state PyPI")
        if isinstance(publish_contract, dict)
        else {"enabled": False}
    )
    pypi_receipt = _pypi_receipt(receipts_root)
    if planned_pypi.get("enabled") is True:
        if pypi_outcome == "success":
            if pypi_receipt is None:
                raise ValueError("enabled PyPI publication has no complete receipt")
            if pypi_receipt.get("version") != result["release"]["version"]:
                raise ValueError(
                    "PyPI publication receipt version does not match release"
                )
            if pypi_receipt.get("target") != planned_pypi.get(
                "target"
            ) or pypi_receipt.get("repository_url") != planned_pypi.get("index"):
                raise ValueError("PyPI receipt target does not match the release plan")
            meta_package = _mapping(
                result.get("meta_package"), "release state meta package"
            )
            if pypi_receipt.get("extras") != meta_package.get("extras"):
                raise ValueError("PyPI receipt extras do not match the meta package")
            if pypi_receipt.get("projects") != public_manifest.expected_pypi_projects(
                result
            ):
                raise ValueError("PyPI receipt files do not match release artifacts")
            result["pypi"] = pypi_receipt
        elif pypi_receipt is not None:
            raise ValueError("failed PyPI publication cannot have a complete receipt")
    else:
        if pypi_receipt is not None:
            raise ValueError("disabled PyPI publication produced a receipt")
        if pypi_outcome != "skipped" or pypi_install_outcome != "skipped":
            raise ValueError("disabled PyPI publication jobs must be skipped")
    pypi_failed = planned_pypi.get("enabled") is True and (
        pypi_outcome != "success" or pypi_install_outcome != "success"
    )
    chart_oci_skipped = (
        chart_oci_outcome == "skipped"
        and isinstance(publish_contract, dict)
        and publish_contract.get("chart_oci", {}).get("enabled") is False
    )
    chart_oci_failed = chart_oci_outcome != "success" and not chart_oci_skipped

    publication_items = [*result["images"], *result["families"]]
    publication_not_requested = all(
        "expected_targets" in item
        and not _mapping(
            item["expected_targets"],
            f"publication target contract {item.get('id')!r}",
        )
        for item in publication_items
    )
    if publication_not_requested:
        if (build_outcome, member_outcome, index_outcome) != (
            "skipped",
            "skipped",
            "skipped",
        ):
            raise ValueError("disabled image publication jobs must all be skipped")
        if members or indexes:
            raise ValueError("disabled image publication must not produce receipts")
        for item in publication_items:
            item["status"] = "not-requested"
            item["targets"] = []
        result["release"]["status"] = (
            "complete"
            if not pypi_failed and not chart_oci_failed
            else "publication-failed"
        )
        return result

    failed = build_outcome != "success" or member_outcome != "success"
    for image in result["images"]:
        receipt = members.get(str(image["id"]))
        targets = (
            _validated_receipt_targets(
                receipt, image.get("expected_targets"), f"Image {image['id']} receipt"
            )
            if receipt is not None
            else []
        )
        if receipt is not None and receipt.get("status") == "published":
            image["status"] = "published"
            image["targets"] = targets
        else:
            image["status"] = "failed"
            image["targets"] = targets
            failed = True

    if expected_index_ids and index_outcome != "success":
        failed = True
    for family in result["families"]:
        family_id = str(family["id"])
        if family["create_index"]:
            receipt = indexes.get(family_id)
            targets = (
                _validated_receipt_targets(
                    receipt,
                    family.get("expected_targets"),
                    f"family {family_id} receipt",
                )
                if receipt is not None
                else []
            )
            if receipt is not None and receipt.get("status") == "published":
                family["status"] = "published"
                family["targets"] = targets
            else:
                family["status"] = "failed"
                family["targets"] = targets
                failed = True
        else:
            members_for_family = [
                image
                for image in result["images"]
                if image["family_id"] == family["id"]
            ]
            if len(members_for_family) != 1:
                raise ValueError(f"single-arch family {family_id!r} is ambiguous")
            member = members_for_family[0]
            family["status"] = member["status"]
            family["targets"] = copy.deepcopy(member["targets"])
            failed = failed or member["status"] != "published"

    if failed:
        result["release"]["status"] = "images-failed"
    elif pypi_failed or chart_oci_failed:
        result["release"]["status"] = "publication-failed"
    else:
        result["release"]["status"] = "complete"
    return result


def _target_repository(reference: str, context: str) -> str:
    repository, separator, tag = reference.rpartition(":")
    if not separator or not repository or not tag:
        raise ValueError(f"{context} is not a tagged OCI reference")
    return repository


def _ghcr_package_link(repository: str, target_repository: str) -> str:
    source_parts = repository.split("/")
    target_parts = target_repository.removeprefix("ghcr.io/").split("/")
    if (
        len(source_parts) != 2
        or any(re.fullmatch(r"[A-Za-z0-9_.-]+", part) is None for part in source_parts)
        or len(target_parts) < 2
        or not target_repository.startswith("ghcr.io/")
        or target_parts[0].lower() != source_parts[0].lower()
    ):
        raise ValueError("GHCR target does not belong to the release repository owner")
    package = "/".join(target_parts[1:])
    url = f"https://github.com/{repository}/pkgs/container/{quote(package, safe='')}"
    return f"[`{target_repository}`]({url})"


def _dockerhub_repository_link(target_repository: str) -> str:
    prefix = "docker.io/"
    target_parts = target_repository.removeprefix(prefix).split("/")
    if (
        not target_repository.startswith(prefix)
        or len(target_parts) != 2
        or any(re.fullmatch(r"[A-Za-z0-9_.-]+", part) is None for part in target_parts)
    ):
        raise ValueError("Docker Hub target is not a namespaced repository")
    path = "/".join(target_parts)
    url = f"https://hub.docker.com/r/{quote(path, safe='/')}"
    return f"[`{target_repository}`]({url})"


def _architecture_label(cpu_arch: str) -> str:
    return {"amd64": "x86_64", "arm64": "aarch64"}.get(cpu_arch, cpu_arch)


def _product_title(runtime_repository: str) -> tuple[int, str]:
    name = runtime_repository.rsplit("/", 1)[-1]
    known = {
        "vllm-openai": (0, "vLLM OpenAI"),
        "vllm-ascend": (1, "vLLM-Ascend"),
        "sglang": (2, "SGLang"),
    }
    return known.get(name, (2, name))


def _capability_label(row: dict[str, Any]) -> str:
    accelerators = sorted(row["accelerators"])
    if len(accelerators) != 1:
        raise ValueError("Wheel capability maps to conflicting accelerator runtimes")
    accelerator = accelerators[0]
    name, separator, version = accelerator.partition("-")
    label = f"{name.upper()} {version}" if separator else accelerator
    backend = str(row["backend"])
    if backend.startswith("cann-"):
        label += f" / {backend.removeprefix('cann-').upper()}"
    return label


def _published_python_installs(manifest: dict[str, Any]) -> dict[str, str]:
    receipt = manifest.get("pypi")
    if not receipt or receipt.get("status") != "complete":
        return {}

    receipt = _mapping(receipt, "release manifest PyPI receipt")
    target = receipt.get("target")
    if target not in {"pypi", "testpypi"}:
        raise ValueError("PyPI installation target is unsupported")
    meta_projects = []
    for raw_project in _list(receipt.get("projects"), "release manifest PyPI projects"):
        project = _mapping(raw_project, "release manifest PyPI project")
        if project.get("role") == "meta":
            meta_projects.append(project.get("project"))
    if len(meta_projects) != 1:
        raise ValueError(
            "PyPI installation requires exactly one published meta project"
        )
    meta_project = meta_projects[0]
    version = receipt.get("version")
    extras = _mapping(receipt.get("extras"), "release manifest PyPI extras")
    if (
        not isinstance(meta_project, str)
        or not meta_project
        or not isinstance(version, str)
        or not version
        or not extras
    ):
        raise ValueError("PyPI installation requires complete package coordinates")

    publication = _mapping(
        _mapping(manifest.get("publish"), "release manifest publish").get("pypi"),
        "release manifest PyPI publication",
    )
    simple_index = str(publication.get("simple_index", ""))
    index_url = urlparse(simple_index)
    if index_url.scheme != "https" or not index_url.netloc:
        raise ValueError("PyPI installation requires a valid simple index")
    project_url = (
        f"{index_url.scheme}://{index_url.netloc}/project/"
        f"{quote(meta_project, safe='')}/{quote(version, safe='')}/"
    )
    label = "PyPI" if target == "pypi" else "TestPyPI"
    index_option = ""
    if target == "testpypi":
        dependency_index = publication.get(
            "dependency_index", "https://pypi.org/simple/"
        )
        index_option = (
            f" --index-url {simple_index} --extra-index-url {dependency_index}"
        )
    return {
        str(extra): (
            f"[{label}]({project_url})<br>"
            f'`pip install{index_option} "{meta_project}[{extra}]=={version}"`'
        )
        for extra in extras
    }


def _render_product_tables(
    manifest: dict[str, Any],
    *,
    repository: str,
    asset_urls: dict[str, str],
    link_assets: bool,
) -> list[str]:
    wheels = {str(item["id"]): item for item in manifest["wheels"]}
    python_installs = _published_python_installs(manifest)
    images_by_family: dict[str, list[dict[str, Any]]] = {}
    for image in manifest["images"]:
        images_by_family.setdefault(str(image["family_id"]), []).append(image)
    families_by_product: dict[str, list[dict[str, Any]]] = {}
    for family in manifest["families"]:
        repository_name = str(family["runtime"]["repository"])
        families_by_product.setdefault(repository_name, []).append(family)

    rendered: list[str] = []
    product_order = sorted(
        families_by_product,
        key=lambda item: (*_product_title(item), item),
    )
    for runtime_repository in product_order:
        product_families = families_by_product[runtime_repository]
        rows: dict[tuple[str, str, str], dict[str, Any]] = {}
        target_repositories: dict[str, set[str]] = {
            "ghcr": set(),
            "dockerhub": set(),
        }
        member_count = 0
        published_count = 0
        for family in product_families:
            family_id = str(family["id"])
            members = images_by_family[family_id]
            member_count += len(members)
            family_wheels = [wheels[str(member["wheel_id"])] for member in members]
            keys = {
                (
                    str(wheel["backend"]),
                    str(wheel["runtime_variant"]),
                    str(wheel["python_abi"]),
                )
                for wheel in family_wheels
            }
            if len(keys) != 1:
                raise ValueError(
                    f"release family {family_id!r} spans multiple Wheel capabilities"
                )
            key = next(iter(keys))
            row = rows.setdefault(
                key,
                {
                    "backend": key[0],
                    "python_abi": key[2],
                    "accelerators": set(),
                    "families": [],
                    "wheels": {},
                },
            )
            runtime = family["runtime"]
            row["accelerators"].add(str(runtime["accelerator_runtime"]))
            row["families"].append(
                {
                    "tag": str(runtime["tag"]),
                    "architectures": {str(member["cpu_arch"]) for member in members},
                    "target_tag": None,
                }
            )
            for wheel in family_wheels:
                row["wheels"][str(wheel["cpu_arch"])] = wheel

            target_tag = None
            for channel, label in (("ghcr", "GHCR"), ("dockerhub", "Docker Hub")):
                actual_references = [
                    str(target["reference"])
                    for target in family.get("targets", [])
                    if target.get("channel") == channel
                    and isinstance(target.get("reference"), str)
                ]
                if len(actual_references) > 1:
                    raise ValueError(
                        f"release family {family_id!r} has multiple {label} targets"
                    )
                reference = actual_references[0] if actual_references else None
                if reference is None and channel == "ghcr":
                    reference = family["expected_targets"].get("ghcr")
                if not isinstance(reference, str):
                    continue
                target_repository = _target_repository(
                    reference, f"release family {label} target"
                )
                target_repositories[channel].add(target_repository)
                reference_tag = reference.rpartition(":")[2]
                if target_tag is not None and reference_tag != target_tag:
                    raise ValueError(
                        f"release family {family_id!r} target tags do not match"
                    )
                target_tag = reference_tag
            row["families"][-1]["target_tag"] = target_tag
            if family.get("status") == "published" and family.get("targets"):
                published_count += 1

        _, title = _product_title(runtime_repository)
        rendered.extend([f"## {title}", "", f"Runtime: `{runtime_repository}`", ""])
        repositories: dict[str, str] = {}
        for channel, label in (("ghcr", "GHCR"), ("dockerhub", "Docker Hub")):
            channel_repositories = target_repositories[channel]
            if len(channel_repositories) > 1:
                raise ValueError(f"{title} maps to multiple {label} repositories")
            if channel_repositories:
                repositories[channel] = next(iter(channel_repositories))
        if repositories:
            packages = []
            if "ghcr" in repositories:
                packages.append(
                    f"GHCR {_ghcr_package_link(repository, repositories['ghcr'])}"
                )
            if "dockerhub" in repositories:
                packages.append(
                    "Docker Hub "
                    + _dockerhub_repository_link(repositories["dockerhub"])
                )
            family_count = len(product_families)
            release_status = manifest["release"]["status"]
            if release_status == "complete":
                image_status = (
                    f"{family_count} image families / "
                    f"{member_count} architecture members"
                )
            elif release_status == "images-failed":
                image_status = (
                    f"{published_count}/{family_count} image families published"
                )
            else:
                image_status = (
                    f"building {family_count} image families / "
                    f"{member_count} architecture members"
                )
            rendered.extend([f"Images: {' · '.join(packages)} — {image_status}", ""])

        repository_headers = []
        if "ghcr" in repositories:
            repository_headers.append(f"GHCR: {repositories['ghcr']}")
        if "dockerhub" in repositories:
            repository_headers.append(f"Docker Hub: {repositories['dockerhub']}")

        rendered.extend(
            [
                "| Runtime capability | "
                f"Upstream Runtime tags<br>{runtime_repository}： | "
                "Runtime tags"
                + (
                    "<br>" + "<br>".join(repository_headers)
                    if repository_headers
                    else ""
                )
                + " | Python ABI | Wheel |",
                "| --- | --- | --- | --- | --- |",
            ]
        )
        for key in sorted(rows, key=lambda item: (item[1], item[2], item[0])):
            row = rows[key]
            available_arches = set(row["wheels"])
            upstream_runtime_tags = []
            packaged_runtime_tags = []
            for family in sorted(row["families"], key=lambda item: item["tag"]):
                tag = family["tag"]
                arch_suffix = ""
                if family["architectures"] != available_arches:
                    architectures = ", ".join(
                        _architecture_label(item)
                        for item in sorted(family["architectures"])
                    )
                    arch_suffix = f" ({architectures} only)"
                upstream_runtime_tags.append(f"`{tag}`{arch_suffix}")
                if family["target_tag"] is not None:
                    packaged_runtime_tags.append(
                        f"`{family['target_tag']}`{arch_suffix}"
                    )
            if not packaged_runtime_tags:
                packaged_runtime_tags.append("—")
            runtime_variant = key[1]
            wheel_cell = python_installs.get(runtime_variant)
            if python_installs and wheel_cell is None:
                raise ValueError(
                    f"published Python packages have no extra for {runtime_variant!r}"
                )
            if wheel_cell is None:
                wheel_links = []
                wheel_architectures = [
                    architecture
                    for architecture in ("arm64", "amd64")
                    if architecture in row["wheels"]
                ]
                wheel_architectures.extend(
                    sorted(set(row["wheels"]) - set(wheel_architectures))
                )
                for architecture in wheel_architectures:
                    wheel = row["wheels"][architecture]
                    filename = str(wheel["filename"])
                    label = _architecture_label(architecture)
                    wheel_links.append(
                        f"[{label}]({asset_urls[filename]})"
                        if link_assets
                        else f"`{label}`"
                    )
                wheel_cell = "<br>".join(wheel_links)
            rendered.append(
                "| "
                + " | ".join(
                    (
                        _capability_label(row),
                        "<br>".join(upstream_runtime_tags),
                        "<br>".join(packaged_runtime_tags),
                        f"`{row['python_abi']}`",
                        wheel_cell,
                    )
                )
                + " |"
            )
        rendered.append("")
    return rendered


def render_notes(
    manifest: dict[str, Any],
    *,
    repository: str,
    asset_urls: dict[str, str],
    link_assets: bool = True,
) -> str:
    """Render compact, linked Release notes from the current manifest stage."""
    release = _mapping(manifest.get("release"), "release manifest release")
    lines = [
        f"Status: `{release['status']}`",
        "",
    ]
    if release["status"] == "release-open":
        lines.append("Release artifacts are building.")
        return "\n".join(lines) + "\n"

    artifact_lines = [f"Backend Wheels: {len(manifest.get('wheels', []))}"]
    available_artifacts = "Backend"
    if manifest.get("chart") is not None:
        chart = _mapping(manifest["chart"], "release manifest Chart")
        chart_filename = str(chart.get("filename", ""))
        chart_url = asset_urls.get(chart_filename)
        if not chart_filename or not chart_url:
            raise ValueError("Release notes require a Chart URL")
        chart_line = (
            f"Chart: [{chart_filename}]({chart_url})"
            if link_assets
            else f"Chart: `{chart_filename}`"
        )
        artifact_lines.append(chart_line)
        available_artifacts = "Backend and Chart"
    artifact_lines.append("")
    lines.extend(artifact_lines)
    if release["status"] == "artifacts-ready":
        lines.extend(
            [
                f"> {available_artifacts} artifacts are available. Images are still building.",
                "",
            ]
        )
    elif release["status"] == "images-failed":
        lines.extend(
            [
                f"> {available_artifacts} artifacts remain available, but one or more images failed to publish.",
                "",
            ]
        )
    elif release["status"] == "publication-failed":
        lines.extend(
            [
                f"> {available_artifacts} artifacts remain available, but one or more publication channels failed.",
                "",
            ]
        )
    lines.extend(
        _render_product_tables(
            manifest,
            repository=repository,
            asset_urls=asset_urls,
            link_assets=link_assets,
        )
    )
    toolkit_package = manifest.get("toolkit_package")
    if toolkit_package is not None:
        filename = toolkit_package["filename"]
        lines.extend(["", "## Toolkit", ""])
        if link_assets:
            lines.append(f"[{filename}]({asset_urls[filename]})")
        else:
            lines.append(f"`{filename}`")
        lines.append(
            "Install the optional `toolkit` extra with the same-version meta package, or install this Wheel independently."
        )
    return "\n".join(lines) + "\n"


def _artifacts(arguments: argparse.Namespace) -> None:
    plan = _mapping(_load_json(arguments.plan), "release plan")
    manifest, _ = build_release_state(
        plan,
        arguments.wheels,
        arguments.chart,
        arguments.meta,
        toolkit_root=arguments.toolkit,
        actions_run_id=arguments.run_id,
    )
    _write_json(arguments.output / "release-state.json", manifest)


def _finalize(arguments: argparse.Namespace) -> None:
    manifest = _mapping(_load_json(arguments.manifest), "release manifest")
    result = finalize_release_state(
        manifest,
        arguments.receipts,
        build_outcome=arguments.build_outcome,
        member_outcome=arguments.member_outcome,
        index_outcome=arguments.index_outcome,
        pypi_outcome=arguments.pypi_outcome,
        pypi_install_outcome=arguments.pypi_install_outcome,
        chart_oci_outcome=arguments.chart_oci_outcome,
    )
    _write_json(arguments.output / "release-state.json", result)


def _notes(arguments: argparse.Namespace) -> None:
    manifest = _mapping(_load_json(arguments.manifest), "release manifest")
    release_document = _mapping(
        _load_json(arguments.release), "GitHub Release document"
    )
    asset_urls = public_manifest.asset_urls(manifest, release_document)
    notes = render_notes(
        manifest,
        repository=arguments.repository,
        asset_urls=asset_urls,
        link_assets=release_document.get("draft") is not True,
    )
    (arguments.output / "release-notes.md").write_text(
        release_body.merge_body(release_document.get("body"), notes),
        encoding="utf-8",
    )


def _manifest(arguments: argparse.Namespace) -> None:
    state = _mapping(_load_json(arguments.state), "release state")
    release_document = _mapping(
        _load_json(arguments.release), "GitHub Release document"
    )
    _write_json(
        arguments.output / public_manifest.RELEASE_MANIFEST_FILENAME,
        public_manifest.build_manifest(state, release_document),
    )


def _members(arguments: argparse.Namespace) -> None:
    plan = _mapping(_load_json(arguments.plan), "release plan")
    validate_member_receipts(plan, arguments.receipts)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    artifacts = commands.add_parser("artifacts")
    artifacts.add_argument("--plan", type=Path, required=True)
    artifacts.add_argument("--wheels", type=Path, required=True)
    artifacts.add_argument("--chart", type=Path, required=True)
    artifacts.add_argument("--meta", type=Path)
    artifacts.add_argument("--toolkit", type=Path)
    artifacts.add_argument("--run-id", type=int, required=True)
    artifacts.add_argument("--output", type=Path, required=True)
    artifacts.set_defaults(func=_artifacts)
    finalize = commands.add_parser("finalize")
    finalize.add_argument("--manifest", type=Path, required=True)
    finalize.add_argument("--receipts", type=Path, required=True)
    finalize.add_argument("--build-outcome", required=True)
    finalize.add_argument("--member-outcome", required=True)
    finalize.add_argument("--index-outcome", required=True)
    finalize.add_argument("--pypi-outcome", required=True)
    finalize.add_argument("--pypi-install-outcome", required=True)
    finalize.add_argument("--chart-oci-outcome", required=True)
    finalize.add_argument("--output", type=Path, required=True)
    finalize.set_defaults(func=_finalize)
    notes = commands.add_parser("notes")
    notes.add_argument("--manifest", type=Path, required=True)
    notes.add_argument("--release", type=Path, required=True)
    notes.add_argument("--repository", required=True)
    notes.add_argument("--output", type=Path, required=True)
    notes.set_defaults(func=_notes)
    manifest = commands.add_parser("manifest")
    manifest.add_argument("--state", type=Path, required=True)
    manifest.add_argument("--release", type=Path, required=True)
    manifest.add_argument("--output", type=Path, required=True)
    manifest.set_defaults(func=_manifest)
    members = commands.add_parser("members")
    members.add_argument("--plan", type=Path, required=True)
    members.add_argument("--receipts", type=Path, required=True)
    members.add_argument("--output", type=Path, required=True)
    members.set_defaults(func=_members)
    return parser


def main() -> int:
    arguments = build_parser().parse_args()
    arguments.output.mkdir(parents=True, exist_ok=True)
    arguments.func(arguments)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
