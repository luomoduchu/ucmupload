from __future__ import annotations

import importlib
import json
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
SCRIPT = ROOT / "scripts" / "materialize_version.py"
sys.path.insert(0, str(ROOT / ".github" / "release"))
materialize = importlib.import_module("ucm_release.version_config")

VERSION_CONFIG = (
    "UCM_VERSION=0.7.62\n"
    "UCM_SUPPORTED_VLLM_VERSIONS=0.27.1\n"
    "UCM_SUPPORTED_VLLM_ASCEND_VERSIONS=0.26\n"
    "UCM_SUPPORTED_SGLANG_VERSIONS=0.5.19\n"
)


@pytest.mark.parametrize(
    "value",
    [
        "v0.7.59RC5",
        "draft/v0.6.0-0",
        "nightly/v0.7.62-20260826-0",
        "nightly/v0.7.62-20260230-1",
    ],
)
def test_invalid_or_noncanonical_tags_are_rejected(value: str) -> None:
    with pytest.raises(ValueError):
        materialize.version_from_tag(value)


def test_cli_replaces_only_ucm_version_and_prints_it(tmp_path: Path) -> None:
    output = tmp_path / "version.ini"
    output.write_text(VERSION_CONFIG, encoding="utf-8")
    completed = subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            "--tag",
            "draft/v0.6.0-13",
            "--output",
            str(output),
        ],
        text=True,
        capture_output=True,
        check=True,
    )

    assert completed.stdout == "0.6.0.dev13\n"
    assert output.read_text(encoding="utf-8") == VERSION_CONFIG.replace(
        "UCM_VERSION=0.7.62", "UCM_VERSION=0.6.0.dev13"
    )


@pytest.mark.parametrize(
    ("tag", "expected"),
    [
        (
            "v0.7.62",
            {
                "git_tag": "v0.7.62",
                "release_type": "stable",
                "release_kind": "publish",
                "version": "0.7.62",
                "chart_version": "0.7.62",
                "image_version": "0.7.62",
                "is_prerelease": False,
            },
        ),
        (
            "v0.7.62rc3",
            {
                "git_tag": "v0.7.62rc3",
                "release_type": "prerelease",
                "release_kind": "publish",
                "version": "0.7.62rc3",
                "chart_version": "0.7.62-rc.3",
                "image_version": "0.7.62rc3",
                "is_prerelease": True,
            },
        ),
        (
            "draft/v0.7.62",
            {
                "git_tag": "draft/v0.7.62",
                "release_type": "draft",
                "release_kind": "draft",
                "version": "0.7.62.dev0",
                "chart_version": "0.7.62-draft.0",
                "image_version": "0.7.62.dev0",
                "is_prerelease": True,
            },
        ),
        (
            "draft/v0.7.62-4",
            {
                "git_tag": "draft/v0.7.62-4",
                "release_type": "draft",
                "release_kind": "draft",
                "version": "0.7.62.dev4",
                "chart_version": "0.7.62-draft.4",
                "image_version": "0.7.62.dev4",
                "is_prerelease": True,
            },
        ),
        (
            "nightly/v0.7.62-20260826-1",
            {
                "git_tag": "nightly/v0.7.62-20260826-1",
                "release_type": "nightly",
                "release_kind": "publish",
                "version": "0.7.62.dev20260826001",
                "chart_version": "0.7.62-nightly.20260826.1",
                "image_version": "0.7.62.dev20260826001",
                "is_prerelease": True,
            },
        ),
    ],
)
def test_classify_tag(tag: str, expected: dict[str, object]) -> None:
    assert materialize.classify_tag(tag) == expected


@pytest.mark.parametrize("suffix,label", [("test", "test"), ("1-test", "1.test")])
def test_named_draft_coordinates_round_trip_without_losing_identity(
    suffix: str, label: str
) -> None:
    tag = f"draft/v0.9.0-{suffix}"
    version = f"0.9.0.dev0+draft.{label}"
    classified = materialize.classify_tag(tag)

    assert classified["version"] == version
    assert classified["chart_version"] == f"0.9.0-draft.{label}"
    assert classified["image_version"] == f"0.9.0.dev0.draft.{label}"
    assert materialize.custom_draft_tag(version) == tag
    assert materialize.derive_chart_version(version) == classified["chart_version"]


@pytest.mark.parametrize(
    "suffix",
    [
        "",
        "01",
        "Test",
        "test.gpu",
        "test_gpu",
        "test--gpu",
        "test-01",
        "test gpu",
    ],
)
def test_draft_labels_reject_normalization_and_empty_segments(suffix: str) -> None:
    with pytest.raises(ValueError):
        materialize.classify_tag(f"draft/v0.9.0-{suffix}")


@pytest.mark.parametrize(
    "version",
    [
        "0.9.0+draft.test",
        "0.9.0.dev1+draft.test",
        "0.9.0rc1.dev0+draft.test",
        "0.9.0.dev0+gabcdef",
        "0.9.0.dev0+draft.1",
        "0.9.0.dev0+draft.test.01",
    ],
)
def test_new_release_versions_only_allow_canonical_named_draft_locals(
    version: str,
) -> None:
    with pytest.raises(ValueError):
        materialize.materialize_bytes(VERSION_CONFIG, version)


def test_named_draft_cli_materializes_the_complete_version(tmp_path: Path) -> None:
    output = tmp_path / "version.ini"
    output.write_text(VERSION_CONFIG, encoding="utf-8")
    tag = "draft/v0.7.62-1-test"
    version = "0.7.62.dev0+draft.1.test"

    completed = subprocess.run(
        [sys.executable, str(SCRIPT), "--tag", tag, "--output", str(output)],
        text=True,
        capture_output=True,
        check=True,
    )

    assert completed.stdout.strip() == version
    parsed = materialize.load(output)
    assert parsed["ucm_version"] == version
    assert parsed["ucm_base_version"] == "0.7.62"
    assert (
        parsed["authority_sha256"]
        == materialize.parse(VERSION_CONFIG)["authority_sha256"]
    )
    assert materialize.validate_tag_against_config(tag, output)["version"] == version
    with pytest.raises(ValueError, match="base version differs"):
        materialize.validate_tag_against_config("draft/v0.7.63-1-test", output)


def test_named_draft_rejects_an_overlong_final_image_tag() -> None:
    runtime = importlib.import_module("ucm_release.runtime")
    long_version = materialize.classify_tag("draft/v0.9.0-" + "a" * 110)[
        "image_version"
    ]
    with pytest.raises(ValueError, match="128-character limit"):
        runtime.project_runtime_image_tag(
            f"my-runtime-ucm-{long_version}",
            tag_prefix="fork-owner-",
            architectures=["amd64", "arm64"],
        )


def test_classify_cli_does_not_materialize_version(tmp_path: Path) -> None:
    output = tmp_path / "version.ini"
    completed = subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            "--tag",
            "draft/v0.7.62",
            "--classify",
            "--output",
            str(output),
        ],
        text=True,
        capture_output=True,
        check=True,
    )

    assert json.loads(completed.stdout) == materialize.classify_tag("draft/v0.7.62")
    assert not output.exists()


def test_next_nightly_sequence_is_scoped_to_base_and_date() -> None:
    tags = [
        "nightly/v0.7.62-20260826-1",
        "nightly/v0.7.62-20260826-3",
        "nightly/v0.7.62-20260825-9",
        "nightly/v0.7.63-20260826-8",
        "nightly/v0.7.62-20260826-04",
    ]

    assert (
        materialize.next_nightly_sequence(
            tags, base_version="0.7.62", release_date="20260826"
        )
        == 4
    )
    assert (
        materialize.next_nightly_sequence(
            tags, base_version="0.7.62", release_date="20260827"
        )
        == 1
    )


def test_next_nightly_cli_outputs_classification_without_materializing(
    tmp_path: Path,
) -> None:
    tags_file = tmp_path / "tags.txt"
    tags_file.write_text(
        "\n".join(
            [
                "v0.7.61",
                "v0.8.0rc1",
                "nightly/v0.7.62-20260826-1",
                "nightly/v0.7.62-20260826-2",
            ]
        ),
        encoding="utf-8",
    )
    output = tmp_path / "version.ini"
    config = tmp_path / "source-version.ini"
    config.write_text(VERSION_CONFIG, encoding="utf-8")

    completed = subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            "--next-nightly",
            "--tags-file",
            str(tags_file),
            "--date",
            "20260826",
            "--version-config",
            str(config),
            "--output",
            str(output),
        ],
        text=True,
        capture_output=True,
        check=True,
    )

    assert json.loads(completed.stdout) == materialize.classify_tag(
        "nightly/v0.7.62-20260826-3"
    )
    assert not output.exists()


@pytest.mark.parametrize(
    "tag",
    [
        "v0.7.62",
        "v0.7.62rc3",
        "draft/v0.7.62-4",
        "nightly/v0.7.62-20260826-1",
    ],
)
def test_tag_base_must_match_version_config(tmp_path: Path, tag: str) -> None:
    config = tmp_path / "version.ini"
    config.write_text(VERSION_CONFIG, encoding="utf-8")

    assert materialize.validate_tag_against_config(tag, config)["git_tag"] == tag
    with pytest.raises(ValueError, match="base version differs"):
        materialize.validate_tag_against_config(tag.replace("0.7.62", "0.7.63"), config)


def test_version_config_supports_minor_patch_and_explicit_tag_selectors() -> None:
    parsed = materialize.parse(
        "UCM_VERSION=0.9.3\n"
        "UCM_SUPPORTED_VLLM_VERSIONS=0.27,0.28.1\n"
        "UCM_SUPPORTED_VLLM_ASCEND_VERSIONS=@nightly-releases-v0.25.1rc\n"
        "UCM_SUPPORTED_SGLANG_VERSIONS=@v0.5.19-cu129\n"
    )

    assert parsed["supported_runtimes"]["vllm"] == [
        {"raw": "0.27", "version": "0.27", "tag": None},
        {"raw": "0.28.1", "version": "0.28.1", "tag": None},
    ]
    assert parsed["supported_runtimes"]["vllm-ascend"] == [
        {
            "raw": "@nightly-releases-v0.25.1rc",
            "version": None,
            "tag": "nightly-releases-v0.25.1rc",
        }
    ]
    assert parsed["supported_runtimes"]["sglang"] == [
        {
            "raw": "@v0.5.19-cu129",
            "version": None,
            "tag": "v0.5.19-cu129",
        }
    ]


@pytest.mark.parametrize(
    "text",
    [
        "UCM_SUPPORTED_VLLM_VERSIONS=0.27.1\n",
        "UCM_VERSION=0.9.3\nUCM_SUPPORTED_VLLM_VERSIONS=0.27,0.27.1\nUCM_SUPPORTED_VLLM_ASCEND_VERSIONS=0.26\nUCM_SUPPORTED_SGLANG_VERSIONS=0.5.19\n",
        "UCM_VERSION=0.9.3\nUCM_SUPPORTED_VLLM_VERSIONS=latest\nUCM_SUPPORTED_VLLM_ASCEND_VERSIONS=0.26\nUCM_SUPPORTED_SGLANG_VERSIONS=0.5.19\n",
        "UCM_VERSION=0.9.3\nUCM_SUPPORTED_VLLM_VERSIONS=0.27.1@bad/tag\nUCM_SUPPORTED_VLLM_ASCEND_VERSIONS=0.26\nUCM_SUPPORTED_SGLANG_VERSIONS=0.5.19\n",
    ],
)
def test_version_config_rejects_missing_ucm_version_or_invalid_selectors(
    text: str,
) -> None:
    with pytest.raises(ValueError):
        materialize.parse(text)


@pytest.mark.parametrize("mode", ["missing", "empty"])
def test_disabled_product_survives_render_and_materialize(mode: str) -> None:
    key = "UCM_SUPPORTED_VLLM_VERSIONS"
    line = next(line for line in VERSION_CONFIG.splitlines() if line.startswith(key))
    text = VERSION_CONFIG.replace(f"{line}\n", f"{key}=\n" if mode == "empty" else "")
    parsed = materialize.parse(text)
    rendered = materialize.render(parsed)

    updated = materialize.parse(
        materialize.materialize_bytes(text, "0.7.62.dev1").decode()
    )
    assert parsed["supported_runtimes"]["vllm"] == []
    assert key not in rendered
    assert updated["ucm_version"] == "0.7.62.dev1"
    assert updated["supported_runtimes"] == parsed["supported_runtimes"]
    assert (
        updated["authority_sha256"] == materialize.parse(rendered)["authority_sha256"]
    )


def test_single_enabled_product_with_mixed_selectors_round_trips() -> None:
    text = "UCM_VERSION=0.9.0\nUCM_SUPPORTED_VLLM_VERSIONS=0.29,@custom-build\n"
    parsed = materialize.parse(text)

    assert materialize.render(parsed) == text
    updated = materialize.materialize_bytes(text, "0.9.0.dev1").decode()
    assert updated == text.replace("UCM_VERSION=0.9.0", "UCM_VERSION=0.9.0.dev1")


@pytest.mark.parametrize(
    "suffix",
    ["", "".join(f"{key}=\n" for key in materialize.SUPPORTED_VERSION_KEYS.values())],
)
def test_all_products_disabled_is_rejected(suffix: str) -> None:
    with pytest.raises(ValueError, match="at least one Runtime product"):
        materialize.parse(f"UCM_VERSION=0.9.0\n{suffix}")


@pytest.mark.parametrize(
    "selector,message",
    [
        ("0.30@v0.30.0", "use @Tag instead"),
        ("@", "invalid OCI tag"),
        ("@repo/image:v0.30.0", "invalid OCI tag"),
        ("@v0.30.0,@v0.30.0", "duplicates an earlier OCI tag"),
        ("0.30,", "non-empty selector"),
    ],
)
def test_invalid_selectors_have_actionable_errors(selector: str, message: str) -> None:
    with pytest.raises(ValueError, match=message):
        materialize.parse(
            f"UCM_VERSION=0.9.0\nUCM_SUPPORTED_VLLM_VERSIONS={selector}\n"
        )


@pytest.mark.parametrize(
    "text,message",
    [
        ("UCM_VERSION=\nUCM_SUPPORTED_VLLM_VERSIONS=0.30\n", "must not be empty"),
        (VERSION_CONFIG + "UCM_SUPPORTED_VLLM_VERSIONS=\n", "duplicate version key"),
        (VERSION_CONFIG + "UNKNOWN_VERSION=\n", "unsupported version key"),
    ],
)
def test_required_and_unique_version_assignments_remain_strict(
    text: str, message: str
) -> None:
    with pytest.raises(ValueError, match=message):
        materialize.parse(text)
