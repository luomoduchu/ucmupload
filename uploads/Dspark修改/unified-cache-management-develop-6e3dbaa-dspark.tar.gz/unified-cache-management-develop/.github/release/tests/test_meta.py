"""Contract tests for the empty public PyPI meta package."""

from __future__ import annotations

import base64
import copy
import csv
import hashlib
import importlib
import importlib.metadata
import io
import os
import subprocess
import sys
import tomllib
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
RELEASE_ROOT = ROOT / ".github" / "release"
sys.path.insert(0, str(RELEASE_ROOT))

meta = importlib.import_module("ucm_release.meta")

VERSION = "0.9.1"


def _plan(version: str = VERSION) -> dict[str, object]:
    return {
        "kind": "ucm-release-plan",
        "repository": "ModelEngine-Group/unified-cache-management",
        "publication_scope": "official",
        "version": version,
        "publish": {"pypi": {"distribution_prefix": ""}},
        "meta_package": {
            "distribution": "uc-manager",
            "version": version,
            "extras": {
                "cu130": f"uc-manager-cuda-cu130=={version}",
                "cann901-a2": f"uc-manager-cann901-a2=={version}",
            },
        },
        "wheels": [
            {
                "id": "cuda130-cp312-amd64",
                "dist_name": "uc-manager-cuda-cu130",
                "wheel_version": version,
                "runtime_variant": "cu130",
            },
            {
                "id": "cuda130-cp312-arm64",
                "dist_name": "uc-manager-cuda-cu130",
                "wheel_version": version,
                "runtime_variant": "cu130",
            },
            {
                "id": "cann901-a2-cp312-arm64",
                "dist_name": "uc-manager-cann901-a2",
                "wheel_version": version,
                "runtime_variant": "cann901-a2",
            },
        ],
    }


def _fork_plan(version: str = VERSION) -> dict[str, object]:
    plan = copy.deepcopy(_plan(version))
    plan["repository"] = "SuperMarioYL/unified-cache-management"
    plan["publication_scope"] = "fork"
    plan["publish"]["pypi"]["distribution_prefix"] = "supermarioyl-"
    for wheel in plan["wheels"]:
        wheel["dist_name"] = f"supermarioyl-{wheel['dist_name']}"
    meta_package = plan["meta_package"]
    meta_package["distribution"] = "supermarioyl-uc-manager"
    meta_package["extras"] = {
        extra: f"supermarioyl-{requirement}"
        for extra, requirement in meta_package["extras"].items()
    }
    return plan


def _named_draft_plan(version: str, git_tag: str) -> dict[str, object]:
    plan = _fork_plan(version)
    plan.update(git_tag=git_tag, release_type="draft")
    plan["toolkit_package"] = {
        "distribution": "supermarioyl-ucm-toolkit",
        "version": version,
    }
    plan["meta_package"]["extras"]["toolkit"] = f"supermarioyl-ucm-toolkit=={version}"
    return plan


def _record(members: dict[str, bytes], record_name: str) -> bytes:
    rows: list[list[str]] = []
    for name in sorted(members):
        content = members[name]
        digest = (
            base64.urlsafe_b64encode(hashlib.sha256(content).digest())
            .decode("ascii")
            .rstrip("=")
        )
        rows.append([name, f"sha256={digest}", str(len(content))])
    rows.append([record_name, "", ""])
    buffer = io.StringIO(newline="")
    csv.writer(buffer, lineterminator="\n").writerows(rows)
    return buffer.getvalue().encode("utf-8")


def _write_wheel(
    path: Path,
    *,
    version: str = VERSION,
    extras: dict[str, str] | None = None,
    payload: dict[str, bytes] | None = None,
    distribution: str = "uc-manager",
) -> None:
    extras = extras or {
        "cann901-a2": f"uc-manager-cann901-a2=={version}",
        "cu130": f"uc-manager-cuda-cu130=={version}",
    }
    filename_distribution = distribution.replace("-", "_")
    dist_info = f"{filename_distribution}-{version}.dist-info"
    metadata = "\n".join(
        (
            "Metadata-Version: 2.4",
            f"Name: {distribution}",
            f"Version: {version}",
            "Requires-Python: >=3.10",
            *(f"Provides-Extra: {extra}" for extra in sorted(extras)),
            *(
                f'Requires-Dist: {requirement}; extra == "{extra}"'
                for extra, requirement in sorted(extras.items())
            ),
            "",
        )
    ).encode("utf-8")
    wheel_metadata = "\n".join(
        (
            "Wheel-Version: 1.0",
            "Generator: ucm-release-test",
            "Root-Is-Purelib: true",
            "Tag: py3-none-any",
            "",
        )
    ).encode("utf-8")
    members = {
        f"{dist_info}/METADATA": metadata,
        f"{dist_info}/WHEEL": wheel_metadata,
        f"{dist_info}/top_level.txt": b"\n",
        **(payload or {}),
    }
    record_name = f"{dist_info}/RECORD"
    members[record_name] = _record(members, record_name)
    with zipfile.ZipFile(path, "w") as archive:
        for name in sorted(members):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, members[name])


def _build_wheel(source: Path, wheelhouse: Path) -> Path:
    script = (
        "from setuptools.build_meta import build_wheel; "
        f"print(build_wheel({str(wheelhouse)!r}))"
    )
    environment = os.environ.copy()
    environment["SOURCE_DATE_EPOCH"] = str(meta.META_SOURCE_DATE_EPOCH)
    subprocess.run(
        [sys.executable, "-c", script],
        cwd=source,
        check=True,
        capture_output=True,
        text=True,
        env=environment,
    )
    wheels = list(wheelhouse.glob("*.whl"))
    assert len(wheels) == 1
    return wheels[0]


def test_materialized_source_builds_and_records_empty_meta_wheel(
    tmp_path: Path,
) -> None:
    plan = _plan()
    source = tmp_path / "source"
    project_path = meta.materialize_meta_source(plan, source)

    assert [path.name for path in source.iterdir()] == ["pyproject.toml"]
    document = tomllib.loads(project_path.read_text(encoding="utf-8"))
    assert document["project"] == {
        "name": "uc-manager",
        "version": VERSION,
        "description": "Unified Cache Management backend selector",
        "requires-python": ">=3.10",
        "dependencies": [],
        "optional-dependencies": {
            "cann901-a2": [f"uc-manager-cann901-a2=={VERSION}"],
            "cu130": [f"uc-manager-cuda-cu130=={VERSION}"],
        },
    }
    assert document["tool"]["setuptools"] == {"packages": []}

    wheelhouse = tmp_path / "wheelhouse"
    wheelhouse.mkdir()
    wheel_path = _build_wheel(source, wheelhouse)
    result = meta.record_meta_wheel(plan, wheel_path)

    assert result == {
        "kind": "ucm-meta-result",
        "schema_version": 1,
        "distribution": "uc-manager",
        "version": VERSION,
        "filename": f"uc_manager-{VERSION}-py3-none-any.whl",
        "sha256": "sha256:" + hashlib.sha256(wheel_path.read_bytes()).hexdigest(),
        "size": wheel_path.stat().st_size,
        "tags": ["py3-none-any"],
        "extras": {
            "cann901-a2": f"uc-manager-cann901-a2=={VERSION}",
            "cu130": f"uc-manager-cuda-cu130=={VERSION}",
        },
        "requires_dist": [
            f'uc-manager-cann901-a2=={VERSION}; extra == "cann901-a2"',
            f'uc-manager-cuda-cu130=={VERSION}; extra == "cu130"',
        ],
    }


def test_materialized_source_build_is_reproducible(tmp_path: Path) -> None:
    wheels: list[Path] = []
    for name in ("first", "second"):
        source = tmp_path / name / "source"
        wheelhouse = tmp_path / name / "wheelhouse"
        wheelhouse.mkdir(parents=True)
        meta.materialize_meta_source(_plan(), source)
        wheels.append(_build_wheel(source, wheelhouse))

    assert wheels[0].read_bytes() == wheels[1].read_bytes()


@pytest.mark.parametrize("version", ["0.9.0.dev0", "0.9.0.dev0+draft.other"])
def test_named_draft_meta_rejects_a_lost_or_foreign_package_label(version: str) -> None:
    plan = _named_draft_plan(version, "draft/v0.9.0-test")
    with pytest.raises(ValueError, match="custom Draft package version differs"):
        meta.validate_meta_package(plan)


def test_named_draft_meta_requires_the_full_backend_dependency_version() -> None:
    plan = _named_draft_plan("0.9.0.dev0+draft.test", "draft/v0.9.0-test")
    plan["meta_package"]["extras"][
        "cu130"
    ] = "supermarioyl-uc-manager-cuda-cu130==0.9.0.dev0"
    with pytest.raises(ValueError, match="must pin"):
        meta.validate_meta_package(plan)


def test_fork_meta_source_and_wheel_use_the_owner_namespace(tmp_path: Path) -> None:
    plan = _fork_plan()
    source = tmp_path / "source"
    project_path = meta.materialize_meta_source(plan, source)
    document = tomllib.loads(project_path.read_text(encoding="utf-8"))

    assert document["project"]["name"] == "supermarioyl-uc-manager"
    assert document["project"]["optional-dependencies"] == {
        "cann901-a2": [f"supermarioyl-uc-manager-cann901-a2=={VERSION}"],
        "cu130": [f"supermarioyl-uc-manager-cuda-cu130=={VERSION}"],
    }

    wheelhouse = tmp_path / "wheelhouse"
    wheelhouse.mkdir()
    wheel_path = _build_wheel(source, wheelhouse)
    result = meta.record_meta_wheel(plan, wheel_path)

    assert wheel_path.name == (f"supermarioyl_uc_manager-{VERSION}-py3-none-any.whl")
    assert result["distribution"] == "supermarioyl-uc-manager"
    assert all(
        requirement.startswith("supermarioyl-uc-manager-")
        for requirement in result["requires_dist"]
    )


def test_named_draft_meta_preserves_full_version_and_installs_extra_offline(
    tmp_path: Path,
) -> None:
    version = "0.9.0.dev0+draft.1.test"
    plan = _named_draft_plan(version, "draft/v0.9.0-1-test")
    meta_source = tmp_path / "meta-source"
    meta_wheelhouse = tmp_path / "named-draft-meta-wheelhouse"
    meta_wheelhouse.mkdir()
    meta.materialize_meta_source(plan, meta_source)
    meta_wheel = _build_wheel(meta_source, meta_wheelhouse)
    result = meta.record_meta_wheel(plan, meta_wheel)
    assert meta_wheel.name == f"supermarioyl_uc_manager-{version}-py3-none-any.whl"
    assert result["version"] == version
    assert result["extras"] == plan["meta_package"]["extras"]
    assert result["requires_dist"] == sorted(
        f'{requirement}; extra == "{extra}"'
        for extra, requirement in plan["meta_package"]["extras"].items()
    )

    backend_source = tmp_path / "backend-source"
    backend_source.mkdir()
    (backend_source / "pyproject.toml").write_text(
        "\n".join(
            (
                "[build-system]",
                'requires = ["setuptools==75.8.2", "wheel==0.45.1"]',
                'build-backend = "setuptools.build_meta"',
                "",
                "[project]",
                'name = "supermarioyl-uc-manager-cuda-cu130"',
                f'version = "{version}"',
                "",
                "[tool.setuptools]",
                "packages = []",
                "",
            )
        ),
        encoding="utf-8",
    )
    backend_wheelhouse = tmp_path / "backend-wheelhouse"
    backend_wheelhouse.mkdir()
    backend_wheel = _build_wheel(backend_source, backend_wheelhouse)
    target = tmp_path / "installed"
    installer_venv = tmp_path / "installer-venv"
    subprocess.run(
        [sys.executable, "-m", "venv", str(installer_venv)],
        check=True,
        capture_output=True,
        text=True,
    )

    subprocess.run(
        [
            str(installer_venv / "bin" / "python"),
            "-m",
            "pip",
            "install",
            "--disable-pip-version-check",
            "--no-index",
            "--target",
            str(target),
            f"{meta_wheel}[cu130]",
            str(backend_wheel),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    installed = {
        distribution.metadata["Name"]: distribution.version
        for distribution in importlib.metadata.distributions(path=[str(target)])
    }
    assert installed == {
        "supermarioyl-uc-manager": version,
        "supermarioyl-uc-manager-cuda-cu130": version,
    }


def test_meta_plan_rejects_swapped_extra_backends() -> None:
    plan = _plan()
    extras = plan["meta_package"]["extras"]
    extras["cu130"], extras["cann901-a2"] = (
        extras["cann901-a2"],
        extras["cu130"],
    )

    with pytest.raises(ValueError, match="must exactly match planned runtime variants"):
        meta.validate_meta_package(plan)


def test_meta_plan_rejects_repository_prefix_drift() -> None:
    plan = _fork_plan()
    plan["publish"]["pypi"]["distribution_prefix"] = "other-owner-"

    with pytest.raises(ValueError, match="prefix differs"):
        meta.validate_meta_package(plan)


def test_meta_wheel_rejects_package_payload(tmp_path: Path) -> None:
    wheel_path = tmp_path / f"uc_manager-{VERSION}-py3-none-any.whl"
    _write_wheel(wheel_path, payload={"ucm/__init__.py": b""})

    with pytest.raises(ValueError, match="must not contain package payload"):
        meta.record_meta_wheel(_plan(), wheel_path)


def test_toolkit_extra_is_separate_from_backend_family(tmp_path):
    plan = _fork_plan()
    plan["toolkit_package"] = {
        "distribution": "supermarioyl-ucm-toolkit",
        "version": VERSION,
    }
    plan["meta_package"]["extras"]["toolkit"] = f"supermarioyl-ucm-toolkit=={VERSION}"
    assert (
        meta.validate_meta_package(plan)["extras"]["toolkit"]
        == f"supermarioyl-ucm-toolkit=={VERSION}"
    )
    source = tmp_path / "source"
    meta.materialize_meta_source(plan, source)
    subprocess.run(
        [
            sys.executable,
            "-m",
            "build",
            "--no-isolation",
            "--wheel",
            "--outdir",
            str(tmp_path / "dist"),
            str(source),
        ],
        check=True,
        capture_output=True,
    )
    result = meta.record_meta_wheel(plan, next((tmp_path / "dist").glob("*.whl")))
    assert result["extras"] == plan["meta_package"]["extras"]
    plan["meta_package"]["extras"]["toolkit"] = "supermarioyl-ucm-toolkit==0.0.1"
    with pytest.raises(ValueError, match="toolkit extra"):
        meta.validate_meta_package(plan)
